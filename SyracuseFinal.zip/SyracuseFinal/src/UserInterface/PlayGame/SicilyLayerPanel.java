
package UserInterface.PlayGame;
import gameengine.GameManagers.GameManager;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import javax.swing.*;
import javax.imageio.ImageIO;

public class SicilyLayerPanel extends JPanel{
    int A=0, B=0;
    Point first = new Point(0,0);
    Point[] pp = new Point[15];
    String city1="",city2="";
    final Random rand = new Random();
    private BufferedImage background,army;
    JPanel panel = new JPanel();
    JLabel title = new JLabel("Sicily",SwingConstants.CENTER);
    static String[] resourceS = {"Barley","Copper","Dye","Flax","Silver","Grape","Iron Ore","Marble","Olive","Salt",
        "Sheep","Timber","Wheat","Barley","Sheep","Wheat"};
    
    BufferedImage[] images = new BufferedImage[12];
    static int[] resource = new int[12];
    int[] points = {211,254,493,170,832,184,996,88,1047,245,1049,645,849,467,945,629,716,386,568,469,414,349,944,416,1164,75,214,142,1087,486};
    String[] names = {"Selinus","Panormus","Apollonia","Tyndaris","Catania","Noto","Gela","Modica","Phintias","Agrigentum","Heracleia","Leontini","Messina","Lilybaeum","Syracuse"};
    Object[][] cities = new Object[2][15];
    GameManager manager;
    int help = 0;
    public SicilyLayerPanel(GameManager mngr){
        manager = mngr;
        setLayout(null);
        
        addMouseListener (new DotsListener());
        
        title.setFont(new java.awt.Font("Serif",Font.BOLD,30));
        title.setForeground(Color.BLACK);   
        title.setBackground(new Color(255, 255, 204, 150));
        title.setOpaque(true);
        title.setBounds(210, 30, 920, 40);
        
        panel.setBackground(new Color(255, 255, 204, 150));
        panel.setBounds(210,85,920,630);
        panel.setLayout(null);
        
        for(int i = 0 ; i < 15 ; i=i+2){
            cities[0][i] = names[i/2];
            cities[1][i] = new Point(points[i],points[i+1]);
        }
        
        for(int i = 0  ; i < 12 ; i++){
            resource[i] = rand.nextInt(11) + 0;
            System.out.println(resourceS[resource[i]]);
        }
          for(int i = 0; i < 30 ; i=i+2)
             if((first.getX()<points[i]&&first.getX()+10>points[i+1]))
	 	  city1 = names[i/2];
          /*for(int i = 0; i < 15 ; i++)
             if((pp[i].getX()<A&&pp[i].getX()+10>A)&&(pp[i].getY()<B&&pp[i].getY()+10>B))
	 	  city2 = names[i];*/
        
    }
    @Override public void paintComponent(Graphics page){ 
   	super.paintComponent(page);
        //composing and drawing army and background image
        try {background = ImageIO.read(getClass().getResource("/file/sicily.gif"));
             army = ImageIO.read(getClass().getResource("/file/g1.png"));} 
        catch (IOException ex) {ex.printStackTrace();}
        page.drawImage(background, 0, 0, this);
        
        //composing resource images
        for(int i = 0  ; i < 12 ; i++){
            try {images[i] = ImageIO.read(getClass().getResource("/file/"+resourceS[resource[i]]+".png"));} 
            catch (IOException ex) {ex.printStackTrace();}
        }
        
        //drawing points
        for(int i = 0 ; i < points.length ; i=i+2){
            page.setColor(Color.BLACK);
            page.fillOval(points[i],points[i+1],10,10);
            pp[i/2] = new Point(points[i],points[i+1]);
            page.setColor(Color.ORANGE);
            page.setFont(new java.awt.Font("Serif",Font.BOLD,20));
            page.drawString(names[i/2],points[i]-20,points[i+1]-5);
        }
        //drawing resource images
        for(int i = 0 ; i < 24 ; i=i+2)
            page.drawImage(images[i/2], (int)pp[i/2].getX()+15, (int)pp[i/2].getY()+5, this);
        
        for(int i = 0 ; i < 30 ; i=i+2){
            page.setColor(Color.BLACK);
            page.setFont(new java.awt.Font("Serif",Font.BOLD,12));
            page.drawImage(army, (int)pp[i/2].getX()-15, (int)pp[i/2].getY()+23, this);
            page.drawString("1000", (int)pp[i/2].getX()-15, (int)pp[i/2].getY()+65);
        }
	//current clicked land
	page.setColor(Color.cyan);
	for(int i = 0; i < 15 ; i++){
            if(help == 1){
                if((pp[i].getX()<getXFromPicture()&&pp[i].getX()+10>getXFromPicture())&&(pp[i].getY()<getYFromPicture()&&pp[i].getY()+10>getYFromPicture()))
	 	  page.fillOval((int)pp[i].getX(), (int)pp[i].getY(), 10 ,10);
                
            }
        }
        repaint();
    }
    static String[] getSources(){
       String[] res = new String[12];
       for(int i  = 0 ;i < 12 ; i++)
           res[i] = resourceS[resource[i]];
       return  res;
    }
    public int getXFromPicture(){
        return A;
   }
   public int getYFromPicture(){
   	return B;
   }
    //Getting X and Y coordinates
    protected class DotsListener implements MouseListener
   {
      public void mousePressed (MouseEvent event)
      {
          
         A=event.getX();
         B=event.getY();
         help = 1;
	System.out.println(A+" "+B);
        
      }
      public void mouseClicked (MouseEvent event) {
          if(event.getClickCount()==2)
              first.setLocation(A, B);
          else if(event.getClickCount()==1)
             System.out.println("city1"+" "+"city2");
        
      }
      public void mouseReleased (MouseEvent event) {}
      public void mouseEntered (MouseEvent event) {}
      public void mouseExited (MouseEvent event) {}
   }
}
