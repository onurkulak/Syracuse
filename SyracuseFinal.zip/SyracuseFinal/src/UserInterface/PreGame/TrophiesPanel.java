
package UserInterface.PreGame;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.swing.*;
import javax.imageio.ImageIO;
import javax.swing.table.*;

public class TrophiesPanel extends JPanel implements ActionListener{
    private BufferedImage background;
    JPanel panel1 = new TransparentPanel();
    JPanel panel2 = new TransparentPanel();
    JLabel title = new JLabel("Trophies",SwingConstants.CENTER);
    String[] units = {"Hoplites","Slingers","Peltasts","Toxotes","Phalangites","Hetairoi","Onager","Manipulus","Equites","Numidian Cavalry",
            "War Elephants","Balearic Slingers","Libyan Infantries","Tarantine cavalry","Mercenary Hoplite","War Chariots"}; 
    
    public TrophiesPanel(){
        
        setLayout(null);
        title.setFont(new java.awt.Font("Serif",Font.BOLD,30));
        title.setForeground(Color.BLACK);   
        title.setBackground(new Color(255, 255, 204, 150));
        title.setOpaque(true);
        title.setBounds(150, 30, 1100, 40);
        
        panel1.setBackground(new Color(255, 255, 204, 150));
        panel1.setLayout(null);
        
        JScrollPane scroll = new JScrollPane(panel1);
        scroll.setBackground(new Color(255, 255, 204, 150));
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBounds(150,80,549,630);
        
        panel2.setBackground(new Color(255, 255, 204, 150));
        panel2.setBounds(701,80,549,630);
        panel2.setLayout(null);
        
        final JLabel savedBattle = new JLabel("Saved Battles");
        savedBattle.setFont(new java.awt.Font("Serif",Font.BOLD,20));
        savedBattle.setForeground(Color.BLACK);   
        savedBattle.setOpaque(false);
        savedBattle.setBounds(200, 20, 200, 30);
        panel1.add(savedBattle);
        
        int[][] army1 = {{5,1000,1000,1000},{3,1000,1000,1000},{2,1000,1000,1000},{1,1000,1000,1000}};
        int[][] army2 = {{1,1000,1000,1000},{12,1000,1000,1000},{4,1000,1000,1000},{15,1000,1000,1000},{3,1000,1000,1000},{0,1000,1000,1000}};
        addBattle(1,"Battle of Aggrigentum","Province: Agrigento",true,"Pericles the Wise of Syracuse",1700,1200,300,army1,
                "Scipo the Cunning of Rome",14000,3000,1200,army2);
        
        int[][] army3 = {{10,1000,1000,1000},{6,1000,1000,1000},{5,1000,1000,1000},{14,1000,1000,1000}};
        int[][] army4 = {{11,1000,1000,1000},{9,1000,1000,1000},{2,1000,1000,1000},{8,1000,1000,1000},{0,1000,1000,1000},{5,1000,1000,1000}};
        addBattle(2,"Battle of XXXXXXXXX","Province: XXXXXXXX",false,"Pericles the Wise of Syracuse",1700,1200,300,army3,
                "Scipo the Cunning of Rome",14000,3000,1200,army4);
                
        add(scroll);
        add(panel2);
        add(title); 
        
    }
    @Override public void paintComponent(Graphics page){ 
   	super.paintComponent(page);
        try {background = ImageIO.read(getClass().getResource("/file/c.jpg"));} 
        catch (IOException ex) {ex.printStackTrace();}
        page.drawImage(background, 0, 0, this);
    }
    
    void addBattle(int numBattle, String name, String province, boolean result, String attackerArmy, int force1, int killed1, int casualties1, int[][] units1,
                                                String defenderArmy, int force2, int killed2, int casualties2, int[][] units2){
        
        final JLabel labelName = new JLabel(name);
        labelName.setFont(new java.awt.Font("Serif",Font.BOLD,20));
        labelName.setForeground(Color.BLACK);   
        labelName.setOpaque(false);
        labelName.setBounds(190, 30, 300, 25);
        
        final JLabel labelProvince = new JLabel(province);
        labelProvince.setFont(new java.awt.Font("Serif",Font.BOLD,15));
        labelProvince.setForeground(Color.BLACK);   
        labelProvince.setOpaque(false);
        labelProvince.setBounds(220, 60, 300, 20);
        
        final JLabel labelResult = new JLabel();
        if(result)  labelResult.setText("Clear Victory");
        else  labelResult.setText("Clear Defeat");
        labelResult.setFont(new java.awt.Font("Serif",Font.BOLD,15));
        labelResult.setForeground(Color.BLACK);   
        labelResult.setOpaque(false);
        labelResult.setBounds(240, 85, 300, 20);
        
        final JButton headButton = new JButton(name+" - "+labelResult.getText());
        headButton.addActionListener(this);
        headButton.setFont(new java.awt.Font("Serif",Font.BOLD,14));
        headButton.setOpaque(false);
        headButton.setBackground(new Color(255, 255, 204, 50));
        headButton.setBounds(150,30+numBattle*40,300,30);
        
        final JLabel labelAttacker = new JLabel("<html>Attacker Army: "+attackerArmy+"<br>Total Force: "+force1+"<br>Killed: "+killed1+
                "<br>Casualties: "+casualties1+"</html>");
        labelAttacker.setFont(new java.awt.Font("Serif",Font.BOLD,13));
        labelAttacker.setForeground(Color.BLACK);   
        labelAttacker.setOpaque(false);
        labelAttacker.setBounds(20, 120, 500, 80);
        
        String[] attackerColumnNames = {"Unit","Count","Killed","Casualties"};
        Object[][] attackerData = new Object[units1.length][units1[0].length];
        
        for(int i  = 0; i < units1.length ; i++){
            attackerData[i][0] = units[units1[i][0]];
            for(int j = 1 ; j < units1[i].length ; j++)
                attackerData[i][j] = units1[i][j];
        }
        JTable attackerTable = new JTable(attackerData, attackerColumnNames); 
        final JTableHeader attackerHeader = attackerTable.getTableHeader();
        
        attackerHeader.setOpaque(true);
        attackerHeader.setBackground(new Color(255, 255, 204, 80));
        
        attackerTable.setOpaque(false);
        attackerTable.setBackground(new Color(255, 255, 204, 80));
        attackerTable.setEnabled(false);
        
        final JScrollPane scroll = new JScrollPane(attackerTable);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBounds(20,210,365,130);
        
        for (int i = 0; i < units.length; i++) 
            attackerTable.setRowHeight(i, 20);
        attackerTable.setFont(new Font("Serif", Font.BOLD, 15));
        attackerTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        attackerTable.getColumnModel().getColumn(0).setPreferredWidth(120);
        
        
        final JLabel labelDefender = new JLabel("<html>Defender Army: "+defenderArmy+"<br>Total Force: "+force2+"<br>Killed: "+killed2+
                "<br>Casualties: "+casualties2+"</html>");
        labelDefender.setFont(new java.awt.Font("Serif",Font.BOLD,13));
        labelDefender.setForeground(Color.BLACK);   
        labelDefender.setOpaque(false);
        labelDefender.setBounds(20, 380, 500, 80);
        
        String[] defenderColumnNames = {"Unit","Count","Killed","Casualties"};
        Object[][] defenderData = new Object[units2.length][units2[0].length];
        for(int i  = 0; i < units2.length ; i++){
            defenderData[i][0] = units[units2[i][0]];
            for(int j = 1 ; j < units2[i].length ; j++)
                defenderData[i][j] = units2[i][j];
        }
        JTable defenderTable = new JTable(defenderData, defenderColumnNames); 
        final JTableHeader defenderHeader = defenderTable.getTableHeader();
        
        defenderHeader.setOpaque(true);
        defenderHeader.setBackground(new Color(255, 255, 204, 80));
        
        defenderTable.setOpaque(false);
        defenderTable.setBackground(new Color(255, 255, 204, 80));
        defenderTable.setEnabled(false);
        
        final JScrollPane scroll2 = new JScrollPane(defenderTable);
        scroll2.setOpaque(false);
        scroll2.getViewport().setOpaque(false);
        scroll2.setBounds(20,470,365,130);
        
        for (int i = 0; i < units.length; i++) 
            defenderTable.setRowHeight(i, 20);
        defenderTable.setFont(new Font("Serif", Font.BOLD, 15));
        defenderTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        defenderTable.getColumnModel().getColumn(0).setPreferredWidth(120);
    
        headButton.addActionListener(new ActionListener() { 
          public void actionPerformed(ActionEvent event) { 
            panel2.removeAll();
                
        
            panel2.add(labelName);
            panel2.add(labelProvince);
            panel2.add(labelResult);
            panel2.add(labelAttacker);
            panel2.add(scroll);
            panel2.add(attackerHeader);
            panel2.add(labelDefender);
            panel2.add(scroll2);
            panel2.add(defenderHeader);
            panel2.revalidate();
            panel2.repaint();
            
          } 
        } );   
        panel1.add(headButton);
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        
    }
    
    private class TransparentPanel extends JPanel {
        {
            setOpaque(false);
        }
            @Override
        public void paintComponent(Graphics g) {
            g.setColor(getBackground());
            Rectangle r = g.getClipBounds();
            g.fillRect(r.x, r.y, r.width, r.height);
            super.paintComponent(g);
        }
    }
}
