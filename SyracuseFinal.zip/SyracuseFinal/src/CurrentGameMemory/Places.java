/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CurrentGameMemory;

import gameengine.GameElementClasses.CityProvince;
import gameengine.GameElementClasses.County;
import gameengine.GameElementClasses.LandProvince;
import gameengine.GameElementClasses.RawMaterial;
import gameengine.GameElementClasses.Region;
import gameengine.GameElementClasses.SeaProvince;

/**
 *
 * @author onur
 */
public class Places {

    private final Region Numantia,
            Baetica,
            QartHadast,
            Ibossini,
            Tarraco,
            Tolosa,
            Massalia,
            Corsica,
            Sardinia,
            Medhlan,
            Patavium,
            Genua,
            Velathri,
            Ariminium,
            Roma,
            Neapolis,
            Brundisium,
            Cosentia,
            Syracuse,
            Messina,
            Lilybaeum,
            Carthago,
            Thapsus,
            Lepcis,
            Iol,
            Tingis,
            Dimmidi,
            Illyria,
            Epidamnos,
            Apollonia,
            Pella,
            Larissa,
            Athenai,
            Corinth,
            Sparta,
            Byzantion,
            Nicomedia,
            Pergamon,
            Ephesus,
            Halicarnassus,
            Ancyra,
            Amaseia,
            Cappadocia,
            Tarsus,
            Antioch,
            Armenia,
            Caucasia,
            Media,
            Parthia,
            Edessa,
            Seleucia,
            Susa,
            Tyros,
            Palmyria,
            Dura,
            Jerusalem,
            Alexandria,
            Memphis,
            Diospolis,
            Amnomium,
            Cyrene,
            Petra,
            Adummatu,
            Gerrha,
            Rhodos,
            Cyprus,
            Crete;

    private final CityProvince MessinaProvince,
            SyracuseProvince,
            LilybaeumProvince;
    private final SeaProvince MessinaPort,
            SyracusePort,
            LilybaeumPort;

    private final County Selinus,
            Panormus,
            ApolloniaCounty,
            Tyndaris,
            Catania,
            Noto,
            Gela,
            Modica,
            Phintias,
            Agrigentum,
            Heracleia,
            Leontini;

    private final Region [] allRegions;
    private final County[] allCounties;
    private final CityProvince[] allCities;
    private final SeaProvince[] allSeaProvinces;
    
    
    public Places(Materials materialsList, String[] countyMaterials) {

        Numantia = new Region(materialsList.getBarley(), "Numantia");
        Baetica = new Region(materialsList.getGrapeJuice(), "Baetica");
        QartHadast = new Region(materialsList.getIron(), "QartHadast");
        Ibossini = new Region(materialsList.getSaltedFish(), "Ibossini");
        Tarraco = new Region(materialsList.getSilver(), "Tarraco");
        Tolosa = new Region(materialsList.getBarley(), "Tolosa");
        Massalia = new Region(materialsList.getOliveOil(), "Massalia");
        Corsica = new Region(materialsList.getSaltedFish(), "Corsica");
        Sardinia = new Region(materialsList.getGlass(), "Sardinia");
        Medhlan = new Region(materialsList.getSaltedMeat(), "Medhlan");
        Patavium = new Region(materialsList.getSlave(), "Patavium");
        Genua = new Region(materialsList.getSilver(), "Genua");
        Velathri = new Region(materialsList.getGrapeJuice(), "Velathri");
        Ariminium = new Region(materialsList.getOliveOil(), "Ariminium");
        Roma = new Region(materialsList.getCloth(), "Roma");
        Neapolis = new Region(materialsList.getCopper(), "Neapolis");
        Brundisium = new Region(materialsList.getSaltedFish(), "Brundisium");
        Cosentia = new Region(materialsList.getCheese(), "Cosentia");
        Syracuse = new Region(materialsList.getWheat(), "Syracuse");
        Messina = new Region(materialsList.getBarley(), "Messina");
        Lilybaeum = new Region(materialsList.getGlass(), "Lilybaeum");
        Carthago = new Region(materialsList.getDyedCloth(), "Carthago");
        Thapsus = new Region(materialsList.getWheat(), "Thapsus");
        Lepcis = new Region(materialsList.getIvory(), "Lepcis");
        Iol = new Region(materialsList.getLumber(), "Iol");
        Tingis = new Region(materialsList.getDye(), "Tingis");
        Dimmidi = new Region(materialsList.getSlave(), "Dimmidi");
        Illyria = new Region(materialsList.getIron(), "Illyria");
        Epidamnos = new Region(materialsList.getGrapeJuice(), "Epidamnos");
        Apollonia = new Region(materialsList.getProcessedMarble(), "Apollonia");
        Pella = new Region(materialsList.getCheese(), "Pella");
        Larissa = new Region(materialsList.getProcessedMarble(), "Larissa");
        Athenai = new Region(materialsList.getDyedCloth(), "Athenai");
        Corinth = new Region(materialsList.getOliveOil(), "Corinth");
        Sparta = new Region(materialsList.getIron(), "Sparta");
        Byzantion = new Region(materialsList.getSalt(), "Byzantion");
        Nicomedia = new Region(materialsList.getBarley(), "Nicomedia");
        Pergamon = new Region(materialsList.getProcessedMarble(), "Pergamon");
        Ephesus = new Region(materialsList.getCloth(), "Ephesus");
        Halicarnassus = new Region(materialsList.getOliveOil(), "Halicarnassus");
        Ancyra = new Region(materialsList.getCloth(), "Ancyra");
        Amaseia = new Region(materialsList.getLumber(), "Amaseia");
        Cappadocia = new Region(materialsList.getGrapeJuice(), "Cappadocia");
        Tarsus = new Region(materialsList.getCloth(), "Tarsus");
        Antioch = new Region(materialsList.getDye(), "Antioch");
        Armenia = new Region(materialsList.getSaltedMeat(), "Armenia");
        Caucasia = new Region(materialsList.getGold(), "Caucasia");
        Media = new Region(materialsList.getSaltedMeat(), "Media");
        Parthia = new Region(materialsList.getBarley(), "Parthia");
        Edessa = new Region(materialsList.getSaltedMeat(), "Edessa");
        Seleucia = new Region(materialsList.getWheat(), "Seleucia");
        Susa = new Region(materialsList.getIvory(), "Susa");
        Tyros = new Region(materialsList.getLumber(), "Tyros");
        Palmyria = new Region(materialsList.getGlass(), "Palmyria");
        Dura = new Region(materialsList.getSilver(), "Dura");
        Jerusalem = new Region(materialsList.getCheese(), "Jerusalem");
        Alexandria = new Region(materialsList.getWheat(), "Alexandria");
        Memphis = new Region(materialsList.getWheat(), "Memphis");
        Diospolis = new Region(materialsList.getGold(), "Diospolis");
        Amnomium = new Region(materialsList.getIvory(), "Amnomium");
        Cyrene = new Region(materialsList.getSaltedFish(), "Cyrene");
        Petra = new Region(materialsList.getSalt(), "Petra");
        Adummatu = new Region(materialsList.getSalt(), "Adummatu");
        Gerrha = new Region(materialsList.getSlave(), "Gerrha");
        Rhodos = new Region(materialsList.getCopper(), "Rhodos");
        Cyprus = new Region(materialsList.getCopper(), "Cyprus");
        Crete = new Region(materialsList.getPot(), "Crete");

        Region[] NumantiaNeighbors = new Region[]{Baetica, QartHadast, Tarraco};
        Region[] BaeticaNeighbors = new Region[]{Numantia, QartHadast, Tingis};
        Region[] QartHadastNeighbors = new Region[]{Numantia, Tarraco, Ibossini, Baetica};
        Region[] IbossiniNeighbors = new Region[]{QartHadast, Sardinia, Iol};
        Region[] TarracoNeighbors = new Region[]{Numantia, QartHadast, Tolosa, Corsica};
        Region[] TolosaNeighbors = new Region[]{Tarraco, Massalia};
        Region[] MassaliaNeighbors = new Region[]{Tolosa, Medhlan, Genua};
        Region[] CorsicaNeighbors = new Region[]{Tarraco, Genua, Velathri, Sardinia};
        Region[] SardiniaNeighbors = new Region[]{Ibossini, Corsica, Lilybaeum, Carthago};
        Region[] MedhlanNeighbors = new Region[]{Massalia, Patavium, Genua};
        Region[] PataviumNeighbors = new Region[]{Medhlan, Illyria, Ariminium, Velathri};
        Region[] GenuaNeighbors = new Region[]{Massalia, Corsica, Medhlan, Velathri};
        Region[] VelathriNeighbors = new Region[]{Corsica, Patavium, Genua, Ariminium, Roma};
        Region[] AriminiumNeighbors = new Region[]{Patavium, Velathri, Roma, Neapolis, Brundisium};
        Region[] RomaNeighbors = new Region[]{Velathri, Ariminium, Neapolis};
        Region[] NeapolisNeighbors = new Region[]{Ariminium, Roma, Brundisium, Cosentia};
        Region[] BrundisiumNeighbors = new Region[]{Ariminium, Neapolis, Cosentia, Epidamnos};
        Region[] CosentiaNeighbors = new Region[]{Neapolis, Brundisium, Messina};
        Region[] SyracuseNeighbors = new Region[]{};
        Region[] MessinaNeighbors = new Region[]{Cosentia};
        Region[] LilybaeumNeighbors = new Region[]{Sardinia, Carthago};
        Region[] CarthagoNeighbors = new Region[]{Sardinia, Lilybaeum, Thapsus, Iol};
        Region[] ThapsusNeighbors = new Region[]{Carthago, Lepcis, Iol};
        Region[] LepcisNeighbors = new Region[]{Thapsus, Iol, Dimmidi, Amnomium};
        Region[] IolNeighbors = new Region[]{Ibossini, Carthago, Thapsus, Lepcis, Tingis, Dimmidi};
        Region[] TingisNeighbors = new Region[]{Baetica, Iol, Dimmidi};
        Region[] DimmidiNeighbors = new Region[]{Lepcis, Iol, Tingis};
        Region[] IllyriaNeighbors = new Region[]{Patavium, Epidamnos};
        Region[] EpidamnosNeighbors = new Region[]{Brundisium, Illyria, Apollonia, Pella, Larissa};
        Region[] ApolloniaNeighbors = new Region[]{Epidamnos, Larissa, Athenai};
        Region[] PellaNeighbors = new Region[]{Epidamnos, Byzantion, Larissa};
        Region[] LarissaNeighbors = new Region[]{Epidamnos, Apollonia, Pella, Athenai};
        Region[] AthenaiNeighbors = new Region[]{Apollonia, Larissa, Corinth, Ephesus, Crete};
        Region[] CorinthNeighbors = new Region[]{Athenai, Sparta};
        Region[] SpartaNeighbors = new Region[]{Corinth};
        Region[] ByzantionNeighbors = new Region[]{Pella, Nicomedia, Pergamon};
        Region[] NicomediaNeighbors = new Region[]{Byzantion, Pergamon, Amaseia, Ancyra};
        Region[] PergamonNeighbors = new Region[]{Byzantion, Nicomedia, Ephesus, Ancyra};
        Region[] EphesusNeighbors = new Region[]{Athenai, Pergamon, Halicarnassus, Ancyra, Tarsus};
        Region[] HalicarnassusNeighbors = new Region[]{Ephesus, Rhodos, Crete, Cyprus, Tarsus};
        Region[] AncyraNeighbors = new Region[]{Nicomedia, Pergamon, Ephesus, Amaseia, Tarsus, Cappadocia};
        Region[] AmaseiaNeighbors = new Region[]{Nicomedia, Ancyra, Cappadocia, Armenia, Caucasia};
        Region[] CappadociaNeighbors = new Region[]{Ancyra, Amaseia, Tarsus, Armenia, Antioch, Edessa};
        Region[] TarsusNeighbors = new Region[]{Ephesus, Halicarnassus, Ancyra, Cappadocia, Antioch};
        Region[] AntiochNeighbors = new Region[]{Cappadocia, Tarsus, Cyprus, Tyros, Palmyria, Dura, Edessa};
        Region[] ArmeniaNeighbors = new Region[]{Amaseia, Cappadocia, Caucasia, Media, Parthia, Edessa};
        Region[] CaucasiaNeighbors = new Region[]{Amaseia, Armenia, Media};
        Region[] MediaNeighbors = new Region[]{Armenia, Caucasia, Parthia};
        Region[] ParthiaNeighbors = new Region[]{Armenia, Media, Susa, Seleucia, Edessa};
        Region[] EdessaNeighbors = new Region[]{Cappadocia, Antioch, Armenia, Parthia, Dura, Seleucia};
        Region[] SeleuciaNeighbors = new Region[]{Parthia, Edessa, Susa, Dura, Gerrha};
        Region[] SusaNeighbors = new Region[]{Parthia, Seleucia, Gerrha};
        Region[] TyrosNeighbors = new Region[]{Antioch, Cyprus, Palmyria, Jerusalem};
        Region[] PalmyriaNeighbors = new Region[]{Antioch, Tyros, Dura, Jerusalem, Adummatu};
        Region[] DuraNeighbors = new Region[]{Antioch, Edessa, Seleucia, Palmyria, Adummatu, Gerrha};
        Region[] JerusalemNeighbors = new Region[]{Tyros, Palmyria, Adummatu, Alexandria, Petra};
        Region[] AlexandriaNeighbors = new Region[]{Jerusalem, Memphis, Petra, Cyprus, Amnomium};
        Region[] MemphisNeighbors = new Region[]{Alexandria, Amnomium, Diospolis};
        Region[] DiospolisNeighbors = new Region[]{Memphis, Amnomium};
        Region[] AmnomiumNeighbors = new Region[]{Lepcis, Alexandria, Memphis, Cyrene};
        Region[] CyreneNeighbors = new Region[]{Amnomium, Crete};
        Region[] PetraNeighbors = new Region[]{Jerusalem, Alexandria, Adummatu};
        Region[] AdummatuNeighbors = new Region[]{Palmyria, Dura, Jerusalem, Petra};
        Region[] GerrhaNeighbors = new Region[]{Seleucia, Susa, Dura};
        Region[] RhodosNeighbors = new Region[]{Halicarnassus, Crete, Cyprus};
        Region[] CyprusNeighbors = new Region[]{Halicarnassus, Antioch, Tyros, Alexandria, Rhodos};
        Region[] CreteNeighbors = new Region[]{Athenai, Halicarnassus, Cyrene, Rhodos};

        Numantia.setNeighbors(NumantiaNeighbors);
        Baetica.setNeighbors(BaeticaNeighbors);
        QartHadast.setNeighbors(QartHadastNeighbors);
        Ibossini.setNeighbors(IbossiniNeighbors);
        Tarraco.setNeighbors(TarracoNeighbors);
        Tolosa.setNeighbors(TolosaNeighbors);
        Massalia.setNeighbors(MassaliaNeighbors);
        Corsica.setNeighbors(CorsicaNeighbors);
        Sardinia.setNeighbors(SardiniaNeighbors);
        Medhlan.setNeighbors(MedhlanNeighbors);
        Patavium.setNeighbors(PataviumNeighbors);
        Genua.setNeighbors(GenuaNeighbors);
        Velathri.setNeighbors(VelathriNeighbors);
        Ariminium.setNeighbors(AriminiumNeighbors);
        Roma.setNeighbors(RomaNeighbors);
        Neapolis.setNeighbors(NeapolisNeighbors);
        Brundisium.setNeighbors(BrundisiumNeighbors);
        Cosentia.setNeighbors(CosentiaNeighbors);
        Syracuse.setNeighbors(SyracuseNeighbors);
        Messina.setNeighbors(MessinaNeighbors);
        Lilybaeum.setNeighbors(LilybaeumNeighbors);
        Carthago.setNeighbors(CarthagoNeighbors);
        Thapsus.setNeighbors(ThapsusNeighbors);
        Lepcis.setNeighbors(LepcisNeighbors);
        Iol.setNeighbors(IolNeighbors);
        Tingis.setNeighbors(TingisNeighbors);
        Dimmidi.setNeighbors(DimmidiNeighbors);
        Illyria.setNeighbors(IllyriaNeighbors);
        Epidamnos.setNeighbors(EpidamnosNeighbors);
        Apollonia.setNeighbors(ApolloniaNeighbors);
        Pella.setNeighbors(PellaNeighbors);
        Larissa.setNeighbors(LarissaNeighbors);
        Athenai.setNeighbors(AthenaiNeighbors);
        Corinth.setNeighbors(CorinthNeighbors);
        Sparta.setNeighbors(SpartaNeighbors);
        Byzantion.setNeighbors(ByzantionNeighbors);
        Nicomedia.setNeighbors(NicomediaNeighbors);
        Pergamon.setNeighbors(PergamonNeighbors);
        Ephesus.setNeighbors(EphesusNeighbors);
        Halicarnassus.setNeighbors(HalicarnassusNeighbors);
        Ancyra.setNeighbors(AncyraNeighbors);
        Amaseia.setNeighbors(AmaseiaNeighbors);
        Cappadocia.setNeighbors(CappadociaNeighbors);
        Tarsus.setNeighbors(TarsusNeighbors);
        Antioch.setNeighbors(AntiochNeighbors);
        Armenia.setNeighbors(ArmeniaNeighbors);
        Caucasia.setNeighbors(CaucasiaNeighbors);
        Media.setNeighbors(MediaNeighbors);
        Parthia.setNeighbors(ParthiaNeighbors);
        Edessa.setNeighbors(EdessaNeighbors);
        Seleucia.setNeighbors(SeleuciaNeighbors);
        Susa.setNeighbors(SusaNeighbors);
        Tyros.setNeighbors(TyrosNeighbors);
        Palmyria.setNeighbors(PalmyriaNeighbors);
        Dura.setNeighbors(DuraNeighbors);
        Jerusalem.setNeighbors(JerusalemNeighbors);
        Alexandria.setNeighbors(AlexandriaNeighbors);
        Memphis.setNeighbors(MemphisNeighbors);
        Diospolis.setNeighbors(DiospolisNeighbors);
        Amnomium.setNeighbors(AmnomiumNeighbors);
        Cyrene.setNeighbors(CyreneNeighbors);
        Petra.setNeighbors(PetraNeighbors);
        Adummatu.setNeighbors(AdummatuNeighbors);
        Gerrha.setNeighbors(GerrhaNeighbors);
        Rhodos.setNeighbors(RhodosNeighbors);
        Cyprus.setNeighbors(CyprusNeighbors);
        Crete.setNeighbors(CreteNeighbors);

        MessinaProvince = new CityProvince("Messina");
        SyracuseProvince = new CityProvince("Syracuse");
        LilybaeumProvince = new CityProvince("Lilybaeum");

        MessinaPort = new SeaProvince("MessinaPort");
        SyracusePort = new SeaProvince("SyracusePort");
        LilybaeumPort = new SeaProvince("LilybaeumPort");

        MessinaProvince.setPortProvince(MessinaPort);
        SyracuseProvince.setPortProvince(SyracusePort);
        LilybaeumProvince.setPortProvince(LilybaeumPort);

        RawMaterial[] materialsFromString = getMaterialsFromString(materialsList , countyMaterials);

        Selinus = new County(materialsFromString[0], "Selinus");
        Panormus = new County(materialsFromString[1], "Panormus");
        ApolloniaCounty = new County(materialsFromString[2], "Apollonia");
        Tyndaris = new County(materialsFromString[3], "Tyndaris");
        Catania = new County(materialsFromString[4], "Catania");
        Noto = new County(materialsFromString[5], "Noto");
        Gela = new County(materialsFromString[6], "Gela");
        Modica = new County(materialsFromString[7], "Modica");
        Phintias = new County(materialsFromString[8], "Phintias");
        Agrigentum = new County(materialsFromString[9], "Agrigentum");
        Heracleia = new County(materialsFromString[10], "Heracleia");
        Leontini = new County(materialsFromString[11], "Leontini");

        SeaProvince[] messinaPortNeighbors = new SeaProvince[]{SyracusePort, LilybaeumPort};
        SeaProvince[] syracusePortNeighbors = new SeaProvince[]{MessinaPort, LilybaeumPort};
        SeaProvince[] lilyBaeumPortNeighbors = new SeaProvince[]{SyracusePort, MessinaPort};
        MessinaPort.setNeighbors(messinaPortNeighbors);
        SyracusePort.setNeighbors(syracusePortNeighbors);
        LilybaeumPort.setNeighbors(lilyBaeumPortNeighbors);
        SyracusePort.setPortOf(SyracuseProvince);
        MessinaPort.setPortOf(MessinaProvince);
        LilybaeumPort.setPortOf(LilybaeumProvince);

        LandProvince[] SelinusNeighbors = new LandProvince[]{LilybaeumProvince,Heracleia,Panormus};
        LandProvince[] PanormusNeighbors = new LandProvince[]{Selinus,LilybaeumProvince,Heracleia,ApolloniaCounty,Phintias};
        LandProvince[] ApolloniaCountyNeighbors = new LandProvince[]{Panormus,Tyndaris,Catania,Leontini,Gela,Phintias};
        LandProvince[] TyndarisNeighbors = new LandProvince[]{ApolloniaCounty,MessinaProvince,Catania};
        LandProvince[] CataniaNeighbors = new LandProvince[]{ApolloniaCounty,Tyndaris,MessinaProvince,SyracuseProvince,Leontini};
        LandProvince[] NotoNeighbors = new LandProvince[]{SyracuseProvince,Leontini,Modica};
        LandProvince[] GelaNeighbors = new LandProvince[]{ApolloniaCounty,Leontini,Modica,Phintias};
        LandProvince[] ModicaNeighbors = new LandProvince[]{Noto,Gela,Leontini};
        LandProvince[] PhintiasNeighbors = new LandProvince[]{Panormus,ApolloniaCounty,Gela,Agrigentum,Heracleia};
        LandProvince[] AgrigentumNeighbors = new LandProvince[]{Phintias,Heracleia};
        LandProvince[] HeracleiaNeighbors = new LandProvince[]{Selinus,Panormus,Phintias,Agrigentum};
        LandProvince[] LeontiniNeighbors = new LandProvince[]{ApolloniaCounty,Catania,Noto,Gela,Modica,SyracuseProvince};
        LandProvince[] MessinaProvinceNeighbors = new LandProvince[]{Tyndaris,Catania};
        LandProvince[] SyracuseProvinceNeighbors = new LandProvince[]{Catania,Noto,Leontini};
        LandProvince[] LilybaeumProvinceNeighbors = new LandProvince[]{Selinus,Panormus};

        Selinus.setNeighbors(SelinusNeighbors);
        Panormus.setNeighbors(PanormusNeighbors);
        ApolloniaCounty.setNeighbors(ApolloniaCountyNeighbors);
        Tyndaris.setNeighbors(TyndarisNeighbors);
        Catania.setNeighbors(CataniaNeighbors);
        Noto.setNeighbors(NotoNeighbors);
        Gela.setNeighbors(GelaNeighbors);
        Modica.setNeighbors(ModicaNeighbors);
        Phintias.setNeighbors(PhintiasNeighbors);
        Agrigentum.setNeighbors(AgrigentumNeighbors);
        Heracleia.setNeighbors(HeracleiaNeighbors);
        Leontini.setNeighbors(LeontiniNeighbors);
        MessinaProvince.setNeighbors(MessinaProvinceNeighbors);
        SyracuseProvince.setNeighbors(SyracuseProvinceNeighbors);
        LilybaeumProvince.setNeighbors(LilybaeumProvinceNeighbors);

        allRegions=new Region[]{
            Numantia,
            Baetica,
            QartHadast,
            Ibossini,
            Tarraco,
            Tolosa,
            Massalia,
            Corsica,
            Sardinia,
            Medhlan,
            Patavium,
            Genua,
            Velathri,
            Ariminium,
            Roma,
            Neapolis,
            Brundisium,
            Cosentia,
            Syracuse,
            Messina,
            Lilybaeum,
            Carthago,
            Thapsus,
            Lepcis,
            Iol,
            Tingis,
            Dimmidi,
            Illyria,
            Epidamnos,
            Apollonia,
            Pella,
            Larissa,
            Athenai,
            Corinth,
            Sparta,
            Byzantion,
            Nicomedia,
            Pergamon,
            Ephesus,
            Halicarnassus,
            Ancyra,
            Amaseia,
            Cappadocia,
            Tarsus,
            Antioch,
            Armenia,
            Caucasia,
            Media,
            Parthia,
            Edessa,
            Seleucia,
            Susa,
            Tyros,
            Palmyria,
            Dura,
            Jerusalem,
            Alexandria,
            Memphis,
            Diospolis,
            Amnomium,
            Cyrene,
            Petra,
            Adummatu,
            Gerrha,
            Rhodos,
            Cyprus,
            Crete
        };
        
        allCounties = new County[]{
            Selinus,
            Panormus,
            ApolloniaCounty,
            Tyndaris,
            Catania,
            Noto,
            Gela,
            Modica,
            Phintias,
            Agrigentum,
            Heracleia,
            Leontini
        };
        
        allCities = new CityProvince[]{
            MessinaProvince,
            SyracuseProvince,
            LilybaeumProvince
        };
        
        allSeaProvinces = new SeaProvince[]{
            SyracusePort,
            MessinaPort,
            LilybaeumPort
        };
    }

    //bunu ayşeyle yap işte
    private RawMaterial[] getMaterialsFromString(Materials materials, String[] materialsString) {
        RawMaterial[] material = new RawMaterial[12];
        for(int i = 0 ; i < 12 ; i++)
            for(int j = 0 ; j < materials.getAllMaterials().length ; j++)
                material[i]=(RawMaterial) materials.getAllMaterials()[i];
        return material;
    }

    public Region getRoma() {
        return Roma;
    }

    public Region getSyracuse() {
        return Syracuse;
    }

    public Region getMessina() {
        return Messina;
    }

    public Region getLilybaeum() {
        return Lilybaeum;
    }

    public Region getCarthago() {
        return Carthago;
    }

    public CityProvince getMessinaProvince() {
        return MessinaProvince;
    }

    public CityProvince getSyracuseProvince() {
        return SyracuseProvince;
    }

    public CityProvince getLilybaeumProvince() {
        return LilybaeumProvince;
    }

    public SeaProvince getMessinaPort() {
        return MessinaPort;
    }

    public SeaProvince getSyracusePort() {
        return SyracusePort;
    }

    public SeaProvince getLilybaeumPort() {
        return LilybaeumPort;
    }
    
    
    
    
}
