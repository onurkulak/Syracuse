/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CurrentGameMemory;

import gameengine.GameElementClasses.PlayerFaction;

/**
 *
 * @author onur
 */
public class Game {

    private ActiveThings activeThings;
    private AIFactions aiFactions;
    private PlayerCivics playerCivics;
    private BuildingsOfSyracuse buildings;
    private Player player;
    private CityStatus cityStatus;
    private PlayerFaction faction;
    private PeopleOfSyracuse people;
    private AllUnits units;
    private int age, turn, money;
    private Materials materials;
    private Places places;
    private String historicalEvents;
    private final int[][] cityMap;

    public Game(Player player, String[] sicilyMaterials) {
        cityMap = new int[132][213]; // dimension etc. will be decided
        instantiateCityMap();
        age = 1;
        money = 30000;
        turn = 0;
        materials = new Materials();
        buildings = new BuildingsOfSyracuse(materials);
        units = new AllUnits();
        //there will be a method to turn strings into resources
        places = new Places(materials, sicilyMaterials);
        historicalEvents = "";
        playerCivics = new PlayerCivics();
        activeThings = new ActiveThings();
        aiFactions = new AIFactions();
        cityStatus = new CityStatus();
        people = new PeopleOfSyracuse();
        faction = new PlayerFaction();
        faction.getCities().add(places.getSyracuseProvince());
        faction.setSyracuse(places.getSyracuseProvince());
    }

    public ActiveThings getActiveThings() {
        return activeThings;
    }

    public void setActiveThings(ActiveThings activeThings) {
        this.activeThings = activeThings;
    }

    public AIFactions getAiFactions() {
        return aiFactions;
    }

    public void setAiFactions(AIFactions aiFactions) {
        this.aiFactions = aiFactions;
    }

    public PlayerCivics getPlayerCivics() {
        return playerCivics;
    }

    public void setPlayerCivics(PlayerCivics playerCivics) {
        this.playerCivics = playerCivics;
    }

    public BuildingsOfSyracuse getBuildings() {
        return buildings;
    }

    public void setBuildings(BuildingsOfSyracuse buildings) {
        this.buildings = buildings;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public CityStatus getCityStatus() {
        return cityStatus;
    }

    public void setCityStatus(CityStatus cityStatus) {
        this.cityStatus = cityStatus;
    }

    public PlayerFaction getFaction() {
        return faction;
    }

    public void setFaction(PlayerFaction faction) {
        this.faction = faction;
    }

    public PeopleOfSyracuse getPeople() {
        return people;
    }

    public void setPeople(PeopleOfSyracuse people) {
        this.people = people;
    }

    public AllUnits getUnits() {
        return units;
    }

    public void setUnits(AllUnits units) {
        this.units = units;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getDate() {
        return turn;
    }

    public void setDate(int date) {
        this.turn = date;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public void pay(int amount) {
        money -= amount;
    }

    public void addMoney(int amount) {
        money += amount;
    }

    public Materials getMaterials() {
        return materials;
    }

    public void setMaterials(Materials materials) {
        this.materials = materials;
    }

    public Places getPlaces() {
        return places;
    }

    public void setPlaces(Places places) {
        this.places = places;
    }

    public String getHistoricalEvents() {
        return historicalEvents;
    }

    public void setHistoricalEvents(String historicalEvents) {
        this.historicalEvents = historicalEvents;
    }

    public int getTurn() {
        return turn;
    }

    public int[][] getCityMap() {
        return cityMap;
    }

    private void instantiateCityMap() {
        for (int i = 0; i < cityMap.length; i++) {
            for (int j = 0; j < cityMap.length; j++) {
                if (i > cityMap.length - 6 || j < 5 || (i > 41 && j > cityMap[0].length - 6)) {
                    cityMap[i][j] = 998;
                } else {
                    cityMap[i][j] = 999;
                }
            }
        }

    }

}
