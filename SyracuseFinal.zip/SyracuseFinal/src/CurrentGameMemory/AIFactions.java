/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CurrentGameMemory;

import gameengine.GameElementClasses.AIFaction;
import gameengine.GameElementClasses.Civic;
import gameengine.GameElementClasses.EconomicCivic;
import gameengine.GameElementClasses.GovernmentCivic;
import gameengine.GameElementClasses.MilitaryCivic;
import gameengine.GameElementClasses.PeloponnesianFaction;
import gameengine.GameElementClasses.SicilyFaction;
import gameengine.GameElementClasses.ThirdAgeFaction;

/**
 *
 * @author onur
 */
public class AIFactions {
    private final AIFaction Corinth;
    private final PeloponnesianFaction Athens, Sparta;
    private final ThirdAgeFaction Antigonids,Seleucids,Ptolemies,FreeCities;
    private final SicilyFaction Rome,Carthage;
    private SicilyFaction rebelFaction;

    private boolean previousTurnCarthageOwnerIsCarthage, previousTurnRomeOwnerIsRome;
    
    public AIFactions(){
        Civic[] corinthFav = new Civic[]{new EconomicCivic("Trade Economy")};
        Civic[] athensFav = new Civic[]{new MilitaryCivic("Militia"), new GovernmentCivic("Democracy"), new EconomicCivic("Trade Economy")};
        Civic[] spartaFav = new Civic[]{new MilitaryCivic("Standing Army"), new GovernmentCivic("Tyranny"), new EconomicCivic("Agrarianism")};
        this.Corinth = new AIFaction(corinthFav,null,"Corinth");
        this.Athens = new PeloponnesianFaction(null, null, athensFav, null, "Athens");
        this.Sparta = new PeloponnesianFaction(null, null, spartaFav, null, "Sparta");;
        this.Antigonids = null;
        this.Seleucids = null;
        this.Ptolemies = null;
        this.FreeCities = null;
        this.Rome = null;
        this.Carthage = null;
        previousTurnCarthageOwnerIsCarthage=true;
        previousTurnRomeOwnerIsRome=true;
    }
    
    public ThirdAgeFaction[] getThirdAgeFactions(){
     ThirdAgeFaction[] list={Antigonids,Seleucids,Ptolemies,FreeCities};
     return list;
    }
    
    public ThirdAgeFaction[] getThirdAgeFactionsWithoutFreeCities(){
     ThirdAgeFaction[] list={Antigonids,Seleucids,Ptolemies};
     return list;
    }
    
    public PeloponnesianFaction[] getPeloponnesianFactions(){
        PeloponnesianFaction[] list={Athens,Sparta};
        return list;
    }
    
    public SicilyFaction[] getSicilyFactions(){
        SicilyFaction[] list={Carthage,Rome,rebelFaction};
        return list;
    }
    
    public SicilyFaction[] getSicilyFactionsWithoutRebelFaction(){
        SicilyFaction[] list={Carthage,Rome};
        return list;
    }

    public AIFaction getCorinth() {
        return Corinth;
    }

    public PeloponnesianFaction getAthens() {
        return Athens;
    }

    public PeloponnesianFaction getSparta() {
        return Sparta;
    }

    public ThirdAgeFaction getAntigonids() {
        return Antigonids;
    }

    public ThirdAgeFaction getSeleucids() {
        return Seleucids;
    }

    public ThirdAgeFaction getPtolemies() {
        return Ptolemies;
    }

    public ThirdAgeFaction getFreeCities() {
        return FreeCities;
    }

    public SicilyFaction getRome() {
        return Rome;
    }

    public SicilyFaction getCarthage() {
        return Carthage;
    }

    public SicilyFaction getRebelFaction() {
        return rebelFaction;
    }

    public void setRebelFaction(SicilyFaction rebelFaction) {
        this.rebelFaction = rebelFaction;
    }

    public boolean isPreviousTurnCarthageOwnerIsCarthage() {
        return previousTurnCarthageOwnerIsCarthage;
    }

    public void setPreviousTurnCarthageOwnerIsCarthage(boolean previousTurnCarthageOwnerIsCarthage) {
        this.previousTurnCarthageOwnerIsCarthage = previousTurnCarthageOwnerIsCarthage;
    }

    public boolean isPreviousTurnRomeOwnerIsRome() {
        return previousTurnRomeOwnerIsRome;
    }

    public void setPreviousTurnRomeOwnerIsRome(boolean previousTurnRomeOwnerIsRome) {
        this.previousTurnRomeOwnerIsRome = previousTurnRomeOwnerIsRome;
    }
    
    
}
