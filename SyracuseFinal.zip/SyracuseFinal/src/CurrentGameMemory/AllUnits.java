/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CurrentGameMemory;

import gameengine.GameElementClasses.LandUnit;
import gameengine.GameElementClasses.Ship;
import java.util.ArrayList;

/**
 *
 * @author onur
 */
public class AllUnits {

    private final ArrayList<LandUnit> availableLandUnits;
    private final ArrayList<Ship> availableNavalUnits;
    private final LandUnit hoplite, slinger, peltast, toxotes, phalangite, hetairoi,
            onager, manipulus, equites, numidianCavalry, warElephant,
            balearicSlinger, libyanInfantry, tarantineCavalry, mercenaryhoplite,
            chariot;
    private final Ship corvus, polyreme, trireme, rammingShip;

    public AllUnits() {

        hoplite = new LandUnit(false, true, false, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 500, 0, 0, 0, 500, 0, 1500, 1, 2, 6, "Hoplite");
        slinger = new LandUnit(false, false, false, 0.5, 1.5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 500, 0, 1000, 1, 2, 4, "Slinger");
        peltast = new LandUnit(false, false, false, 0.3, 0, 1.0, 0, 0, 0, 0, 0, 0, 0, 0, 1000, 0, 0, 0, 500, 0, 1750, 2, 3, 5, "Peltast");
        toxotes = new LandUnit(false, false, false, 0, 0, 0, 0.5, 0, 0, 0.3, 0, 0, 0, 0, 750, 0, 0, 0, 500, 0, 1750, 3, 3, 4, "Toxotes");
        phalangite = new LandUnit(false, true, true, 0, 0, 0, 0, 1.0, 0.3, 0, 0, 0, 0, 0, 500, 0, 0, 500, 500, 0, 2500, 6, 4, 10, "Phalangite");
        hetairoi = new LandUnit(true, true, true, 0, 0, 0.0, 0, 0, 1.0, 0.5, 1.5, 0, 0, 0, 100, 100, 100, 150, 0, 100, 2200, 9, 13, 40, "Hetairoi");
        onager = new LandUnit(false, false, false, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 1000, 7, 15, 0, "Onager");
        manipulus = new LandUnit(false, true, false, 0, 0, 0, 0.7, 0, 0, 0, 0, 0.6, 0, 0, 250, 0, 500, 500, 500, 0, 3000, 8, 3, 13, "Manipulus");
        equites = new LandUnit(true, true, true, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 32, "Equites");
        numidianCavalry = new LandUnit(true, true, false, 0, 0, 0, 0, 1.5, 0, 0, 0, 0, 0, 2.0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 43, "Numidian Cavalry");
        warElephant = new LandUnit(true, true, true, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.3, 0, 0, 0, 0, 0, 20, 0, 0, 0, 75, 300, "War Elephant");
        balearicSlinger = new LandUnit(false, false, false, 0, 0, 0, 0, 0, 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 0, 500, 0, 0, 0, 0, 7, "Balearic Slinger");
        libyanInfantry = new LandUnit(false, true, false, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 500, 0, 0, 0, 0, 5, "Libyan Infantry");
        tarantineCavalry = new LandUnit(true, false, false, 0, 0, 0, 0, 1.0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 9, 28, "Tarantine Cavalry");
        mercenaryhoplite = new LandUnit(false, true, false, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 500, 0, 0, 0, 5, 8, "Mercenary Hoplite");
        chariot = new LandUnit(true, true, false, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4.0, 0, 0, 0, 0, 50, 0, 0, 0, 21, 50, "Chariot");


        hoplite.setAgeRequirement(2);
        slinger.setAgeRequirement(2);
        peltast.setAgeRequirement(3);
        toxotes.setAgeRequirement(3);
        phalangite.setAgeRequirement(3);
        hetairoi.setAgeRequirement(3);
        onager.setAgeRequirement(3);
        manipulus.setAgeRequirement(3);
        equites.setAgeRequirement(4);
        numidianCavalry.setAgeRequirement(4);
        warElephant.setAgeRequirement(4);
        balearicSlinger.setAgeRequirement(4);
        libyanInfantry.setAgeRequirement(4);
        tarantineCavalry.setAgeRequirement(4);
        mercenaryhoplite.setAgeRequirement(4);
        chariot.setAgeRequirement(4);

        corvus = new Ship(80,80,true,false,false,false,50,10,1000,6,300,10,"Corvus Ship");
        polyreme = new Ship(200,180,false,true,false,false,0,20,1100,9,250,35,"Corvus Ship");
        trireme = new Ship(90,90,false,false,true,false,0,10,350,4,100,15,"Corvus Ship"); 
        rammingShip = new Ship(50,25,false,false,false,true,0,5,150,3,70,8,"Corvus Ship");
        
        corvus.setAgeRequirement(3);
        polyreme.setAgeRequirement(3);
        trireme.setAgeRequirement(2);
        rammingShip.setAgeRequirement(3);
        this.availableLandUnits = new ArrayList();
        this.availableNavalUnits = new ArrayList();
    }

    public ArrayList<LandUnit> getAvailableLandUnits() {
        return availableLandUnits;
    }

    public ArrayList<Ship> getAvailableNavalUnits() {
        return availableNavalUnits;
    }

    public LandUnit getHoplite() {
        return hoplite;
    }

    public LandUnit getSlinger() {
        return slinger;
    }

    public LandUnit getPeltast() {
        return peltast;
    }

    public LandUnit getToxotes() {
        return toxotes;
    }

    public LandUnit getPhalangite() {
        return phalangite;
    }

    public LandUnit getHetairoi() {
        return hetairoi;
    }

    public LandUnit getOnager() {
        return onager;
    }

    public LandUnit getManipulus() {
        return manipulus;
    }

    public LandUnit getEquites() {
        return equites;
    }

    public LandUnit getNumidianCavalry() {
        return numidianCavalry;
    }

    public LandUnit getWarElephant() {
        return warElephant;
    }

    public LandUnit getBalearicSlinger() {
        return balearicSlinger;
    }

    public LandUnit getLibyanInfantry() {
        return libyanInfantry;
    }

    public LandUnit getTarantineCavalry() {
        return tarantineCavalry;
    }

    public LandUnit getMercenaryhoplite() {
        return mercenaryhoplite;
    }

    public LandUnit getChariot() {
        return chariot;
    }

    public Ship getCorvus() {
        return corvus;
    }

    public Ship getPolyreme() {
        return polyreme;
    }

    public Ship getTrireme() {
        return trireme;
    }

    public Ship getRammingShip() {
        return rammingShip;
    }

    
}
