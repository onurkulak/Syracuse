/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameElementClasses;

/**
 *
 * @author onur
 */
import java.util.ArrayList;

public class Forge extends ProductionBuilding{
    private final ArrayList<Integer> mansionsNearby;
    private final ArrayList<Integer> forgesNearby;
    
    private final int range = 40;
    
    
    private final double unhappinessForMansion=0.2;
    
    
    public Forge(ManufacturedMaterial[] manufacturedMaterials, Material[] storedResources, int[][] capacities, int cost, int width, int height, int constructionDuration, int id, int upgradeCost1, int upgradeCost2, int maximumAvailableLevel, String name, int[] requiredBuildings, int[] requirementsRange, boolean canBuiltOnlyOnce, int[][] workerCounts) {
        super(manufacturedMaterials, storedResources, capacities, cost, width, height, constructionDuration, id, upgradeCost1, upgradeCost2, maximumAvailableLevel, name, requiredBuildings, requirementsRange, canBuiltOnlyOnce, workerCounts);
        forgesNearby=new ArrayList();
        mansionsNearby=new ArrayList();
    }

    @Override
    protected int getProductionCapacity(int i) {
        return 5000;
    }

    @Override
    public void updateBonuses(int[][] cityMap, Building caller, int buildingInstance) {
        if(!caller.getName().equals("Agora"))
            for(int i=0; i<getInstances().size();i++)
                if(getInstances().get(i).isFinished()){
                    forgesNearby.set(i, numberOfInstancesAroundAnInstance(getInstances().get(i).getxCoordinate(), getInstances().get(i).getyCoordinate(), cityMap, this, range));
                    mansionsNearby.set(i, numberOfInstancesAroundAnInstance(getInstances().get(i).getxCoordinate(), getInstances().get(i).getyCoordinate(), cityMap, getRelatedBuildings().get(0), range));
                }
                    
        super.updateBonuses(cityMap, caller, buildingInstance); //To change body of generated methods, choose Tools | Templates.
    }
    
    public int getUnappinessProduced(){
        double total=0;
        for(int i=0; i<mansionsNearby.size();i++)
            total+=mansionsNearby.get(i);
        return (int)(unhappinessForMansion*total);
    }
    
    
    //will be implemented later
    public int getTotalIronUsed(int productionAmount){
        double totalForgeNeighborhood=0; int totalFinished=0;
        for(int i=0; i<getInstances().size(); i++){
            if(getInstances().get(i).isFinished()){
                double modifier;
                if(getInstances().get(i).getLevel()==1)
                    modifier = 1;
                else if(getInstances().get(i).getLevel()==2)
                    modifier = 1.2;
                else modifier =1.5;
                totalForgeNeighborhood=forgesNearby.get(i)*modifier;
                totalFinished++;
            }
        }   
        int result = productionAmount*(100-(int)(3*totalForgeNeighborhood/totalFinished))/100;
        return result;
    }

    @Override
    public void delete(int x, int y, int[][] cityMap) {
        int i =findInstance(x,y);
        mansionsNearby.remove(i);
        forgesNearby.remove(i);
        super.delete(x, y,cityMap); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void build(int x, int y, boolean alignment) {
        mansionsNearby.add(0);
        forgesNearby.add(0);        
        super.build(x, y, alignment); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
