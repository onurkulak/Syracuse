/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameElementClasses;

/**
 *
 * @author onur
 */
public class Shrine extends WorkBuilding{
    private final int RANGE=30;
    private final int[] housesCoveredByShrines=new int[3];
    private final int[] SHRINE_HAPPINESS={3,4,6};

    public Shrine(int cost, int width, int height, int constructionDuration, int id, int upgradeCost1, int upgradeCost2, int maximumAvailableLevel, String name, int[] requiredBuildings, int[] requirementsRange, boolean canBuiltOnlyOnce, int[][] workerCounts) {
        super(cost, width, height, constructionDuration, id, upgradeCost1, upgradeCost2, maximumAvailableLevel, name, requiredBuildings, requirementsRange, canBuiltOnlyOnce, workerCounts);
    }

    @Override//will be implemented
    public void updateBonuses(int[][] cityMap, Building caller, int buildingInstance) {
        if(!caller.getName().equals("Temple")){
            for(int i=0; i<housesCoveredByShrines.length;i++)
                housesCoveredByShrines[i]=0;
            int[][] cityMapCopy=new int[cityMap.length][cityMap[0].length];
            for(int i=0;i<cityMap.length;i++)
                System.arraycopy(cityMap[i], 0, cityMapCopy[i], 0, cityMap[i].length);
            for(int i=2;i>-1;i--)
                for(int j=0;j<getInstances().size();j++)
                    if(getInstances().get(j).isFinished()&&getInstances().get(j).getLevel()==i+1)
                        housesCoveredByShrines[i]+=numberOfInstancesAroundAnInstanceWithoutCopyArray
        (getInstances().get(j).getxCoordinate(), getInstances().get(j).getyCoordinate(), cityMapCopy, getRelatedBuildings().get(0), RANGE);
        }
    }
    
    public int getHappinessFromShrines(){
        int total=0;
        for (int i=0; i<housesCoveredByShrines.length; i++)
            total+=housesCoveredByShrines[i]*SHRINE_HAPPINESS[i];
        
        return total/60;     
    }
}
