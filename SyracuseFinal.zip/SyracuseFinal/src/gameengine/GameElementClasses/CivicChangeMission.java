/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameElementClasses;

import CurrentGameMemory.Game;

/**
 *
 * @author onur
 */
public class CivicChangeMission extends Mission{
    private final Civic civic;

    public CivicChangeMission(Civic civic, AIFaction sender, String title, String textBody, Reward reward, int penalty, int duration) {
        super(sender, title, textBody, reward, penalty, duration);
        this.civic = civic;
    }

    @Override //if user currently adapted the civic, returns true
    public boolean isAccomplished(Game game) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
