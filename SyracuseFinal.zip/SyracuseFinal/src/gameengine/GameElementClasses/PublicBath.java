/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameElementClasses;

/**
 *
 * @author onur
 */
public class PublicBath extends WorkBuilding{
    private final int RANGE=50;
    private int housesCovered=0, mansionsCovered=0;
    
    public PublicBath(int cost, int width, int height, int constructionDuration, int id, int upgradeCost1, int upgradeCost2, int maximumAvailableLevel, String name, int[] requiredBuildings, int[] requirementsRange, boolean canBuiltOnlyOnce, int[][] workerCounts) {
        super(cost, width, height, constructionDuration, id, upgradeCost1, upgradeCost2, maximumAvailableLevel, name, requiredBuildings, requirementsRange, canBuiltOnlyOnce, workerCounts);
    }
    
//update bonuses method needs to be overwritten
    @Override
    public void updateBonuses(int[][] cityMapReal, Building caller, int buildingInstance) {
        int[][] cityMapCopy = new int[cityMapReal.length][cityMapReal[0].length];
        for (int i = 0; i < cityMapReal.length; i++) {
            System.arraycopy(cityMapReal[i], 0, cityMapCopy[i], 0, cityMapReal[i].length);
        }
        
        if(caller.getName().equals("House")){
            housesCovered=0;
            for(int i=0; i<getInstances().size(); i++)
                if(getInstances().get(i).isFinished())
                    housesCovered+=numberOfInstancesAroundAnInstanceWithoutCopyArray(getInstances().get(i).getxCoordinate(), getInstances().get(i).getyCoordinate(), cityMapCopy, caller, RANGE);
        }
        else if(caller.getName().equals("Mansion")){
            mansionsCovered=0;
            for(int i=0; i<getInstances().size(); i++)
                if(getInstances().get(i).isFinished())
                    mansionsCovered+=numberOfInstancesAroundAnInstanceWithoutCopyArray(getInstances().get(i).getxCoordinate(), getInstances().get(i).getyCoordinate(), cityMapCopy, caller, RANGE);
        }
        else{
            int[][] cityMapCopy2 = new int[cityMapReal.length][cityMapReal[0].length];
        for (int i = 0; i < cityMapReal.length; i++) {
            System.arraycopy(cityMapReal[i], 0, cityMapCopy2[i], 0, cityMapReal[i].length);
        }
            mansionsCovered=0;
            for(int i=0; i<getInstances().size(); i++)
                if(getInstances().get(i).isFinished())
                    mansionsCovered+=numberOfInstancesAroundAnInstanceWithoutCopyArray(getInstances().get(i).getxCoordinate(), getInstances().get(i).getyCoordinate(), cityMapCopy, caller, RANGE);
            housesCovered=0;
            for(int i=0; i<getInstances().size(); i++)
                if(getInstances().get(i).isFinished())
                    housesCovered+=numberOfInstancesAroundAnInstanceWithoutCopyArray(getInstances().get(i).getxCoordinate(), getInstances().get(i).getyCoordinate(), cityMapCopy2, caller, RANGE);
        }
        super.updateBonuses(cityMapReal, caller, buildingInstance); //To change body of generated methods, choose Tools | Templates.
    }
    
    public int getProletariatHappiness(){
        return housesCovered/10;
    }
    
    public int getAristoiHappiness(){
        return mansionsCovered/10;
    }
}
