/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameElementClasses;

/**
 *
 * @author onur
 */
public class SeaProvince extends Province{
    private Navy navy;
    
    private SeaProvince[] neighbors;
    private CityProvince portOf;

    public SeaProvince(String name) {
        super(name);
        navy=null;
    }

    public Navy getNavy() {
        return navy;
    }

    public void setNavy(Navy navy) {
        this.navy = navy;
    }

    public SeaProvince[] getNeighbors() {
        return neighbors;
    }

    public void setNeighbors(SeaProvince[] neighbors) {
        this.neighbors = neighbors;
    }

    public CityProvince getPortOf() {
        return portOf;
    }

    public void setPortOf(CityProvince portOf) {
        this.portOf = portOf;
    }
    
    
}
