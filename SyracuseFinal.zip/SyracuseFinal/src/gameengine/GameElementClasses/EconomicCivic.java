/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameElementClasses;

/**
 *
 * @author onur
 */
public class EconomicCivic extends Civic{

    public EconomicCivic(String name) {
        super(name);
    }
    
}
