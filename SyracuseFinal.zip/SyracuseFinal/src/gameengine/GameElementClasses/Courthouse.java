/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameElementClasses;

/**
 *
 * @author onur
 */
public class Courthouse extends WorkBuilding {

    private int housesInRange, mansionsInRange, militaryBuildingsInRange;
    private final int range = 70;
    private boolean nearBarrack = false, nearSiege = false, nearGenerals = false, nearArchery = false;
    //values needs to be decided
    private final int happinessPerHouse = 1, happinessPerMansion = 1, happinessPerMilitary = 5;

    public Courthouse(int cost, int width, int height, int constructionDuration, int id, int upgradeCost1, int upgradeCost2, int maximumAvailableLevel, String name, int[] requiredBuildings, int[] requirementsRange, boolean canBuiltOnlyOnce, int[][] workerCounts) {
        super(cost, width, height, constructionDuration, id, upgradeCost1, upgradeCost2, maximumAvailableLevel, name, requiredBuildings, requirementsRange, canBuiltOnlyOnce, workerCounts);
        housesInRange = 0;
        mansionsInRange = 0;
        militaryBuildingsInRange = 0;
    }

    public int getHappiness(GovernmentCivic civic) {
        if (civic.getName().equals("Tyranny")) {
            return militaryBuildingsInRange * happinessPerMilitary / 5;
        } else if (civic.getName().equals("Democracy")) {
            return housesInRange * happinessPerHouse / 5;
        } else {
            return happinessPerMansion * mansionsInRange / 5;
        }
    }

    @Override
    public void updateBonuses(int[][] cityMap, Building caller, int buildingInstance) {
        if (doesExist()) {
            if (caller == this) {
                if (buildingInstance == -1) {
                    housesInRange = 0;
                    mansionsInRange = 0;
                    militaryBuildingsInRange = 0;
                    nearBarrack = false;
                    nearSiege = false;
                    nearGenerals = false;
                    nearArchery = false;
                } else {
                    housesInRange = numberOfInstancesAroundAnInstance(getInstances().get(0).getxCoordinate(), getInstances().get(0).getyCoordinate(), cityMap, getRelatedBuildings().get(0), range);
                    mansionsInRange = numberOfInstancesAroundAnInstance(getInstances().get(0).getxCoordinate(), getInstances().get(0).getyCoordinate(), cityMap, getRelatedBuildings().get(1), range);
                    if (isThereInstanceNearby(getInstances().get(0).getxCoordinate(), getInstances().get(0).getyCoordinate(), getRelatedBuildings().get(5).getId(), range, cityMap)) {
                        nearArchery = true;
                        militaryBuildingsInRange++;
                    }
                    if (isThereInstanceNearby(getInstances().get(0).getxCoordinate(), getInstances().get(0).getyCoordinate(), getRelatedBuildings().get(2).getId(), range, cityMap)) {
                        nearBarrack = true;
                        militaryBuildingsInRange++;
                    }
                    if (isThereInstanceNearby(getInstances().get(0).getxCoordinate(), getInstances().get(0).getyCoordinate(), getRelatedBuildings().get(3).getId(), range, cityMap)) {
                        nearSiege = true;
                        militaryBuildingsInRange++;
                    }
                    if (isThereInstanceNearby(getInstances().get(0).getxCoordinate(), getInstances().get(0).getyCoordinate(), getRelatedBuildings().get(4).getId(), range, cityMap)) {
                        nearGenerals = true;
                        militaryBuildingsInRange++;
                    }
                }
            } else {
                switch (caller.getName()) {
                    case "House":
                        housesInRange = numberOfInstancesAroundAnInstance(getInstances().get(0).getxCoordinate(), getInstances().get(0).getyCoordinate(), cityMap, caller, range);
                        break;
                    case "Mansion":
                        mansionsInRange = numberOfInstancesAroundAnInstance(getInstances().get(0).getxCoordinate(), getInstances().get(0).getyCoordinate(), cityMap, caller, range);
                        break;
                    case "Archery Range":
                        if (nearArchery && buildingInstance == -1) {
                            nearArchery = false;
                            militaryBuildingsInRange--;
                        } else if (!nearArchery && buildingInstance != -1) {
                            if (isThereInstanceNearby(getInstances().get(0).getxCoordinate(), getInstances().get(0).getyCoordinate(), caller.getId(), range, cityMap)) {
                                nearArchery = true;
                                militaryBuildingsInRange++;
                            }
                        }
                        break;
                    case "Barrack":
                        if (nearBarrack && buildingInstance == -1) {
                            nearBarrack = false;
                            militaryBuildingsInRange--;
                        } else if (!nearBarrack && buildingInstance != -1) {
                            if (isThereInstanceNearby(getInstances().get(0).getxCoordinate(), getInstances().get(0).getyCoordinate(), caller.getId(), range, cityMap)) {
                                nearBarrack = true;
                                militaryBuildingsInRange++;
                            }
                        }
                        break;
                    case "General's HeadQuarter":
                        if (nearGenerals && buildingInstance == -1) {
                            nearGenerals = false;
                            militaryBuildingsInRange--;
                        } else if (!nearGenerals && buildingInstance != -1) {
                            if (isThereInstanceNearby(getInstances().get(0).getxCoordinate(), getInstances().get(0).getyCoordinate(), caller.getId(), range, cityMap)) {
                                nearGenerals = true;
                                militaryBuildingsInRange++;
                            }
                        }
                        break;
                    case "Siege Workshop":
                        if (nearSiege && buildingInstance == -1) {
                            nearSiege = false;
                            militaryBuildingsInRange--;
                        } else if (!nearSiege && buildingInstance != -1) {
                            if (isThereInstanceNearby(getInstances().get(0).getxCoordinate(), getInstances().get(0).getyCoordinate(), caller.getId(), range, cityMap)) {
                                nearSiege = true;
                                militaryBuildingsInRange++;
                            }
                        }
                        break;
                }
            }
        }
    }
}
