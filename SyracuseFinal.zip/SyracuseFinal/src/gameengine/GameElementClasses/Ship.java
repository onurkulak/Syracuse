/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameElementClasses;

/**
 *
 * @author onur
 */
public class Ship extends Unit{
    private final int lumberRequirement;
    private final int slaveRequirement;
    private final boolean corvus;
    private final boolean polyreme;
    private final boolean trireme;
    private final boolean rammingShip;

    public Ship(int lumberRequirement, int slaveRequirement, boolean corvus, boolean polyreme, boolean trireme, boolean rammingShip, int proletariatRequirement, int aristoiRequirement, int moneyCost, int trainingTime, int monthlyWage, int basePower, String name) {
        super(proletariatRequirement, aristoiRequirement, moneyCost, trainingTime, monthlyWage, basePower, name);
        this.lumberRequirement = lumberRequirement;
        this.slaveRequirement = slaveRequirement;
        this.corvus = corvus;
        this.polyreme = polyreme;
        this.trireme = trireme;
        this.rammingShip = rammingShip;
    }
    
    //will be implemented, returns the power with bonuses
    //needs to be multiplied by ship number for a unit
    public double getPowerAfterBonusesApplied(Navy enemyNavy){
        int[] numbers=new int[4];
        for(int i=0;i<enemyNavy.getShips().size();i++){
            Ship ship = enemyNavy.getShips().get(i);
            if(ship.corvus)
                numbers[0]=enemyNavy.getShipCounts().get(i);
            else if(ship.polyreme)
                numbers[1]=enemyNavy.getShipCounts().get(i);
            else if(ship.rammingShip)
                numbers[2]=enemyNavy.getShipCounts().get(i);
            else if(ship.trireme)
                numbers[3]=enemyNavy.getShipCounts().get(i);
            numbers[4]+=enemyNavy.getShipCounts().get(i);
        }
        if(polyreme)
            return getBasePower()*1.5*(numbers[0]+numbers[4])/numbers[5];
        else if(trireme)
            return getBasePower()*1.5*(numbers[2])/numbers[5];
        else if(rammingShip)
           return getBasePower()*1.5*(numbers[3])/numbers[5];
        else return getBasePower();
    }

    public int getLumberRequirement() {
        return lumberRequirement;
    }

    public int getSlaveRequirement() {
        return slaveRequirement;
    }

    public boolean isCorvus() {
        return corvus;
    }

    public boolean isPolyreme() {
        return polyreme;
    }

    public boolean isTrireme() {
        return trireme;
    }

    public boolean isRammingShip() {
        return rammingShip;
    }
    
    
}
