package gameengine.GameElementClasses;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author onur
 */
//things related to bonus updates calculations need to be implemented in all subclasses
import java.util.ArrayList;

public abstract class Building {

    private final int cost, width, height, constructionDuration, maximumAvailableLevel;
    private final String name;
    private final int[] requiredBuildings, requirementsRange;
    private final boolean canBuiltOnlyOnce;
    private boolean unlocked;
    private final ArrayList<Building> relatedBuildings;
    private final ArrayList<Specification> instances;
    private boolean requirementDependOnlyOnAge;
    private int requirementAge, id;

    public Building(int cost, int width, int height, int constructionDuration, int id, int maximumAvailableLevel, String name, int[] requiredBuildings, int[] requirementsRange, boolean canBuiltOnlyOnce) {
        this.cost = cost;
        this.width = width;
        this.height = height;
        this.constructionDuration = constructionDuration;
        this.id = id;
        this.maximumAvailableLevel = maximumAvailableLevel;
        this.name = name;
        this.requiredBuildings = requiredBuildings;
        this.requirementsRange = requirementsRange;
        this.canBuiltOnlyOnce = canBuiltOnlyOnce;
        relatedBuildings = new ArrayList<>();
        instances = new ArrayList<>();
        unlocked = false;
    }

    //returns the instance of the building in the given coordinates
    public int findInstance(int x, int y) {
        for (int i = 0; i < instances.size(); i++) {
            Specification instance = instances.get(i);
            if (instance.getxCoordinate() <= x
                    && instance.getyCoordinate() <= y) {
                if (instance.isHorizontal()) {
                    if (instance.getxCoordinate() + width > x
                            && instance.getyCoordinate() + height > y) {
                        return i;
                    }
                } else if (instance.getxCoordinate() + height > x
                        && instance.getyCoordinate() + width > y) {
                    return i;
                }
            }
        }

        return -1;
    }
    
    public boolean instancesTouching(int thisInstance, Building targetBuilding, int targetInstance){
        int xStart = getInstances().get(thisInstance).getxCoordinate()-1;
        int yStart = getInstances().get(thisInstance).getyCoordinate()-1;
        int xMost, yMost;
        if(getInstances().get(thisInstance).isHorizontal()){
            xMost = getInstances().get(thisInstance).getxCoordinate()+width;
            yMost = getInstances().get(thisInstance).getyCoordinate()+height;
        }
        else{
            xMost = getInstances().get(thisInstance).getxCoordinate()+height+1;
            yMost = getInstances().get(thisInstance).getyCoordinate()+width+1;
        }
        
        for(int i=xStart; i<xMost; i++)
            for(int j=yStart; j<yMost; j++)
                if(targetBuilding.findInstance(i, j)==targetInstance)
                    return true;
        return false;
    }

    public void passTurn(int[][] cityMap) {
        for (int i = 0; i < instances.size(); i++) {
            if (instances.get(i).construct()) {
                updateBonuses(cityMap, this, i);
                for (Building relatedBuilding : relatedBuildings) {
                    relatedBuilding.updateBonuses(cityMap, this, i);
                }
            }
        }
    }

    //if instance is -1, means this method is called cecause of the deletion
    //of an instance of the caller class
    //needs to be implemented in subclasses separately
    public void updateBonuses(int[][] cityMap, Building caller, int buildingInstance) {

    }

    //needs to be implemented, returns true if there is an instance nearby
    //road id 1039
    //agora id 1001
    public boolean isThereInstanceNearby(int x, int y, int targetId, int range, int[][] cityMap) {
        int[][] cityMapCopy = new int[cityMap.length][cityMap[0].length];
        for (int i = 0; i < cityMap.length; i++) {
            System.arraycopy(cityMap[i], 0, cityMapCopy[i], 0, cityMap[i].length);
        }

        int currentCoordinate = 0;
        int currentRange = 1;
        int[] xCoor = new int[1000];
        int[] yCoor = new int[1000];
        int instance = findInstance(x, y);
        int xlength = (instances.get(instance).isHorizontal()) ? width : height;
        int ylength = (instances.get(instance).isHorizontal()) ? height : width;
        //Add top of the building to queue
        for (int i = 0; i < xlength; i++) {
            if (x + i >= cityMapCopy[0].length || y - 1 < 0)//If out of bounds stop
            {
                break;
            }
            if (cityMapCopy[y - 1][x + i] == targetId)//The case where the target building is constructed near this object
            {
                return true;
            }
            //in case of an agora built adjacent to the building there might be problems finding the shortest path so we need also check
            //if there is already a path length marked before
            if (cityMapCopy[y - 1][x + i] == 1039 || cityMapCopy[y - 1][x + i] < 900) {//The case in which the adjacent block is a road
                xCoor[currentCoordinate] = x + i;
                yCoor[currentCoordinate] = y - 1;
                cityMapCopy[y - 1][x + i] = currentRange;//the length of the road that is already taken
                currentCoordinate++;
            }
            if (cityMapCopy[y - 1][x + i] == 1001) {
                //A method that marks all around the agora with currentRange+1 if there does not exist a building and then marked whole agora with 901
                //Since we already have the shortes paths to all around agora so we do not need to know anymore if this is agora or not.
                agoraMark(cityMapCopy, y - 1, x + i, currentRange, xCoor, yCoor, currentCoordinate);
            }
        }
        //Add righthand side
        int curx = x + xlength - 1;
        int cury = y;
        for (int i = 0; i < ylength; i++) {
            if (cury + i >= cityMapCopy.length || curx + 1 > cityMapCopy[0].length) {
                break;
            }
            if (cityMapCopy[cury + i][curx + 1] == targetId) {
                return true;
            }
            if (cityMapCopy[cury + i][curx + 1] == 1039 || cityMapCopy[cury + i][curx + 1] < 900) {
                xCoor[currentCoordinate] = curx + 1;
                yCoor[currentCoordinate] = cury + i;
                cityMapCopy[cury + i][curx + 1] = currentRange;//the length of the road that is already taken
                currentCoordinate++;
            }
            if (cityMapCopy[cury + i][curx + 1] == 1001) {
                agoraMark(cityMapCopy, cury + i, curx + 1, currentRange, xCoor, yCoor, currentCoordinate);
            }
        }
        //Add bottom
        curx = x;
        cury = cury + ylength - 1;
        for (int i = 0; i < xlength; i++) {
            if (curx + i >= cityMapCopy[0].length || cury - 1 >= cityMapCopy.length) {
                break;
            }
            if (cityMapCopy[cury - 1][curx + i] == targetId) {
                return true;
            }
            if (cityMapCopy[cury - 1][curx + i] == 1039 || cityMapCopy[cury - 1][curx + i] < 900) {
                xCoor[currentCoordinate] = curx + i;
                yCoor[currentCoordinate] = cury - 1;
                cityMapCopy[cury - 1][curx + i] = currentRange;//the length of the road that is already taken
                currentCoordinate++;
            }
            if (cityMapCopy[cury - 1][curx + i] == 1001) {
                agoraMark(cityMapCopy, cury - 1, curx + i, currentRange, xCoor, yCoor, currentCoordinate);
            }
        }
        //Add lefthandside
        for (int i = 0; i < ylength; i++) {
            if (y + i >= cityMapCopy.length || x - 1 < 0) {
                break;
            }
            if (cityMapCopy[y + i][x - 1] == targetId) {
                return true;
            }
            if (cityMapCopy[y + i][x - 1] == 1039 || cityMapCopy[y + i][x - 1] < 900) {
                xCoor[currentCoordinate] = x - 1;
                yCoor[currentCoordinate] = y + i;
                cityMapCopy[y + i][x - 1] = currentRange;
                currentCoordinate++;
            }
            if (cityMapCopy[y + i][x - 1] == 1001) {
                agoraMark(cityMapCopy, y + i, x - 1, currentRange, xCoor, yCoor, currentCoordinate);
            }
        }
        int queueTrace = 0;
        curx = xCoor[queueTrace];
        cury = yCoor[queueTrace];
        queueTrace++;
        currentRange = cityMapCopy[cury][curx];// Now that we have initialized our queue we are moving on to ranges over 1
        while (currentRange <= range) {//the loop where the queue elements will be processed-> xCoor and yCoor arrays
            //top of current point
            if (cury - 1 >= 0) {
                if (cityMapCopy[cury - 1][curx] == targetId) {
                    return true;
                }
                if (cityMapCopy[cury - 1][curx] == 1039 || (cityMapCopy[cury - 1][curx] < 900 && cityMapCopy[cury - 1][curx] > currentRange + 1)) {
                    xCoor[currentCoordinate] = curx;
                    yCoor[currentCoordinate] = cury - 1;
                    cityMapCopy[cury - 1][curx] = currentRange + 1;
                    currentCoordinate++;
                }
                if (cityMapCopy[cury - 1][curx] == 1001) {
                    agoraMark(cityMapCopy, cury - 1, curx, currentRange, xCoor, yCoor, currentCoordinate);
                }
            }
            //rightside of the current point
            if (curx + 1 < xlength) {
                if (cityMapCopy[cury][curx + 1] == targetId) {
                    return true;
                }
                if (cityMapCopy[cury][curx + 1] == 1039 || (cityMapCopy[cury][curx + 1] < 900 && cityMapCopy[cury][curx + 1] > currentRange + 1)) {
                    xCoor[currentCoordinate] = curx + 1;
                    yCoor[currentCoordinate] = cury;
                    cityMapCopy[cury][curx + 1] = currentRange + 1;
                    currentCoordinate++;
                }
                if (cityMapCopy[cury][curx + 1] == 1001) {
                    agoraMark(cityMapCopy, cury, curx + 1, currentRange, xCoor, yCoor, currentCoordinate);
                }
            }
            //bottom of the current point
            if (cury + 1 < ylength) {
                if (cityMapCopy[cury + 1][curx] == targetId) {
                    return true;
                }
                if (cityMapCopy[cury + 1][curx] == 1039 || (cityMapCopy[cury + 1][curx] < 900 && cityMapCopy[cury + 1][curx] > currentRange + 1)) {
                    xCoor[currentCoordinate] = curx;
                    yCoor[currentCoordinate] = cury + 1;
                    cityMapCopy[cury + 1][curx] = currentRange + 1;
                    currentCoordinate++;
                }
                if (cityMapCopy[cury + 1][curx] == 1001) {
                    agoraMark(cityMapCopy, cury + 1, curx, currentRange, xCoor, yCoor, currentCoordinate);
                }
            }
            //lefthandside of the currentt point
            if (curx - 1 >= 0) {
                if (cityMapCopy[cury][curx - 1] == targetId) {
                    return true;
                }
                if (cityMapCopy[cury][curx - 1] == 1039 || (cityMapCopy[cury][curx - 1] < 900 && cityMapCopy[cury][curx - 1] > currentRange + 1)) {
                    xCoor[currentCoordinate] = curx - 1;
                    yCoor[currentCoordinate] = cury;
                    cityMapCopy[cury][curx - 1] = currentRange + 1;
                    currentCoordinate++;
                }
                if (cityMapCopy[cury][curx - 1] == 1001) {
                    agoraMark(cityMapCopy, cury, curx - 1, currentRange, xCoor, yCoor, currentCoordinate);
                }
            }
            curx = xCoor[queueTrace];
            cury = yCoor[queueTrace];
            queueTrace++;
            currentRange = cityMapCopy[cury][curx];
        }
        return false;//if While conditions does not hold it means there is no target building in the given range
    }//Bug in the case where there is an agora in the top of a building and a road in the bottom. The first thing we add
    //to queue has a greater range than others. Possible solution: sort the queue everytime you add sometthing careful though :
    //since we do not delete anything from to queue we just keep iterating

    private void agoraMark(int[][] cityMapCopy, int y1, int x1, int rangeSoFar, int[] xCoor, int[] yCoor, int currentCoordinate) {
        // Find top left point coordinates.
        while (true) {
            boolean op = false;
            if (x1 - 1 >= 0 && cityMapCopy[y1][x1 - 1] == 1001) {
                x1--;
                op = true;
            }

            if (y1 - 1 >= 0 && cityMapCopy[y1 - 1][x1] == 1001) {
                y1--;
                op = true;
            }
            if (!op) {
                break;
            }
        }
        //find size of the agora
        int xlength = 1;
        while (x1 + xlength < cityMapCopy[0].length && cityMapCopy[y1][x1 + xlength] == 1001) {
            xlength++;
        }
        xlength--;
        int ylength = 1;
        while (y1 + ylength < cityMapCopy.length && cityMapCopy[y1 + ylength][x1] == 1001) {
            ylength++;
        }
        ylength--;
        //now mark around the agora

        //Add top of the agora to queue and mark
        for (int i = 0; i < xlength; i++) {
            if (x1 + i >= cityMapCopy[0].length || y1 - 1 < 0)//If out of bounds stop
            {
                break;
            }
            //if there is already a path length marked before
            if (cityMapCopy[y1 - 1][x1 + i] == 1039 || (cityMapCopy[y1 - 1][x1 + i] < 900 && cityMapCopy[y1 - 1][x1 + i] > rangeSoFar + 3)) {//The case in which the adjacent block is a road
                xCoor[currentCoordinate] = x1 + i;
                yCoor[currentCoordinate] = y1 - 1;
                cityMapCopy[y1 - 1][x1 + i] = rangeSoFar + 3;//the length of the road that is already taken
                currentCoordinate++;
            }
            if (cityMapCopy[y1 - 1][x1 + i] == 1001) {
                //A method that marks all around the agora with currentRange+1 if there does not exist a building and then marked whole agora with 901
                //Since we already have the shortes paths to all around agora so we do not need to know anymore if this is agora or not.
                agoraMark(cityMapCopy, y1 - 1, x1 + i, rangeSoFar, xCoor, yCoor, currentCoordinate);
            }
        }
        //Add right hand side of agora
        int curx = x1 + xlength - 1;
        int cury = y1;
        for (int i = 0; i < ylength; i++) {
            if (cury + i >= cityMapCopy.length || curx + 1 > cityMapCopy[0].length) {
                break;
            }
            if (cityMapCopy[cury + i][curx + 1] == 1039 || (cityMapCopy[cury + i][curx + 1] < 900 && cityMapCopy[cury + i][curx + 1] > rangeSoFar + 3)) {
                xCoor[currentCoordinate] = curx + 1;
                yCoor[currentCoordinate] = cury + i;
                cityMapCopy[cury + i][curx + 1] = rangeSoFar + 3;//the length of the road that is already taken
                currentCoordinate++;
            }
            if (cityMapCopy[cury + i][curx + 1] == 1001) {
                agoraMark(cityMapCopy, cury + i, curx + 1, rangeSoFar, xCoor, yCoor, currentCoordinate);
            }
        }

        //Add bottom
        curx = x1;
        cury = cury + ylength - 1;
        for (int i = 0; i < xlength; i++) {
            if (curx + i >= cityMapCopy[0].length || cury - 1 >= cityMapCopy.length) {
                break;
            }
            if (cityMapCopy[cury - 1][curx + i] == 1039 || (cityMapCopy[cury - 1][curx + i] < 900 && cityMapCopy[cury - 1][curx + i] > rangeSoFar + 3)) {
                xCoor[currentCoordinate] = curx + i;
                yCoor[currentCoordinate] = cury - 1;
                cityMapCopy[cury - 1][curx + i] = rangeSoFar + 3;//the length of the road that is already taken
                currentCoordinate++;
            }
            if (cityMapCopy[cury - 1][curx + i] == 1001) {
                agoraMark(cityMapCopy, cury - 1, curx + i, rangeSoFar, xCoor, yCoor, currentCoordinate);
            }
        }

        //Add left hand side
        for (int i = 0; i < ylength; i++) {
            if (y1 + i >= cityMapCopy.length || x1 - 1 < 0) {
                break;
            }
            if (cityMapCopy[y1 + i][x1 - 1] == 1039 || (cityMapCopy[y1 + i][x1 - 1] < 900 && cityMapCopy[y1 + i][x1 - 1] > rangeSoFar + 3)) {
                xCoor[currentCoordinate] = x1 - 1;
                yCoor[currentCoordinate] = y1 + i;
                cityMapCopy[y1 + i][x1 - 1] = rangeSoFar + 3;
                currentCoordinate++;
            }
            if (cityMapCopy[y1 + i][x1 - 1] == 1001) {
                agoraMark(cityMapCopy, y1 + i, x1 - 1, rangeSoFar, xCoor, yCoor, currentCoordinate);
            }
        }
    }

    public int numberOfInstancesAroundAnInstanceWithoutCopyArray(int x, int y, int[][] cityMapCopy, Building targetBuilding, int range) {
        int targetId = targetBuilding.getId();
        int result = 0;
        int currentCoordinate = 0;
        int currentRange = 1;
        int[] xCoor = new int[1000];
        int[] yCoor = new int[1000];
        int instance = findInstance(x, y);
        int xlength = (instances.get(instance).isHorizontal()) ? width : height;
        int ylength = (instances.get(instance).isHorizontal()) ? height : width;
        //Add top of the building to queue
        for (int i = 0; i < xlength; i++) {
            if (x + i >= cityMapCopy[0].length || y - 1 < 0)//If out of bounds stop
            {
                break;
            }
            if (cityMapCopy[y - 1][x + i] == targetId) {//The case where the target building is constructed near this object
                result++;
                paintBuilding(targetBuilding, y - 1, x + i, cityMapCopy);
            }
            //in case of an agora built adjacent to the building there might be problems finding the shortest path so we need also check
            //if there is already a path length marked before
            if (cityMapCopy[y - 1][x + i] == 1039 || cityMapCopy[y - 1][x + i] < 900) {//The case in which the adjacent block is a road
                xCoor[currentCoordinate] = x + i;
                yCoor[currentCoordinate] = y - 1;
                cityMapCopy[y - 1][x + i] = currentRange;//the length of the road that is already taken
                currentCoordinate++;
            }
            if (cityMapCopy[y - 1][x + i] == 1001) {
                //A method that marks all around the agora with currentRange+1 if there does not exist a building and then marked whole agora with 901
                //Since we already have the shortes paths to all around agora so we do not need to know anymore if this is agora or not.
                agoraMark(cityMapCopy, y - 1, x + i, currentRange, xCoor, yCoor, currentCoordinate);
            }
        }
        //Add righthand side
        int curx = x + xlength - 1;
        int cury = y;
        for (int i = 0; i < ylength; i++) {
            if (cury + i >= cityMapCopy.length || curx + 1 > cityMapCopy[0].length) {
                break;
            }
            if (cityMapCopy[cury + i][curx + 1] == targetId) {
                result++;
                paintBuilding(targetBuilding, cury + i, curx + 1, cityMapCopy);
            }
            if (cityMapCopy[cury + i][curx + 1] == 1039 || cityMapCopy[cury + i][curx + 1] < 900) {
                xCoor[currentCoordinate] = curx + 1;
                yCoor[currentCoordinate] = cury + i;
                cityMapCopy[cury + i][curx + 1] = currentRange;//the length of the road that is already taken
                currentCoordinate++;
            }
            if (cityMapCopy[cury + i][curx + 1] == 1001) {
                agoraMark(cityMapCopy, cury + i, curx + 1, currentRange, xCoor, yCoor, currentCoordinate);
            }
        }
        //Add bottom
        curx = x;
        cury = cury + ylength - 1;
        for (int i = 0; i < xlength; i++) {
            if (curx + i >= cityMapCopy[0].length || cury - 1 >= cityMapCopy.length) {
                break;
            }
            if (cityMapCopy[cury - 1][curx + i] == targetId) {
                result++;
                paintBuilding(targetBuilding, cury - 1, curx + i, cityMapCopy);
            }
            if (cityMapCopy[cury - 1][curx + i] == 1039 || cityMapCopy[cury - 1][curx + i] < 900) {
                xCoor[currentCoordinate] = curx + i;
                yCoor[currentCoordinate] = cury - 1;
                cityMapCopy[cury - 1][curx + i] = currentRange;//the length of the road that is already taken
                currentCoordinate++;
            }
            if (cityMapCopy[cury - 1][curx + i] == 1001) {
                agoraMark(cityMapCopy, cury - 1, curx + i, currentRange, xCoor, yCoor, currentCoordinate);
            }
        }
        //Add lefthandside
        for (int i = 0; i < ylength; i++) {
            if (y + i >= cityMapCopy.length || x - 1 < 0) {
                break;
            }
            if (cityMapCopy[y + i][x - 1] == targetId) {
                result++;
                paintBuilding(targetBuilding, y + i, x - 1, cityMapCopy);
            }
            if (cityMapCopy[y + i][x - 1] == 1039 || cityMapCopy[y + i][x - 1] < 900) {
                xCoor[currentCoordinate] = x - 1;
                yCoor[currentCoordinate] = y + i;
                cityMapCopy[y + i][x - 1] = currentRange;
                currentCoordinate++;
            }
            if (cityMapCopy[y + i][x - 1] == 1001) {
                agoraMark(cityMapCopy, y + i, x - 1, currentRange, xCoor, yCoor, currentCoordinate);
            }
        }
        int queueTrace = 0;
        curx = xCoor[queueTrace];
        cury = yCoor[queueTrace];
        queueTrace++;
        currentRange = cityMapCopy[cury][curx];// Now that we have initialized our queue we are moving on to ranges over 1
        while (currentRange <= range) {//the loop where the queue elements will be processed-> xCoor and yCoor arrays
            //top of current point
            if (cury - 1 >= 0) {
                if (cityMapCopy[cury - 1][curx] == targetId) {
                    result++;
                    paintBuilding(targetBuilding, cury - 1, curx, cityMapCopy);
                }
                if (cityMapCopy[cury - 1][curx] == 1039 || (cityMapCopy[cury - 1][curx] < 900 && cityMapCopy[cury - 1][curx] > currentRange + 1)) {
                    xCoor[currentCoordinate] = curx;
                    yCoor[currentCoordinate] = cury - 1;
                    cityMapCopy[cury - 1][curx] = currentRange + 1;
                    currentCoordinate++;
                }
                if (cityMapCopy[cury - 1][curx] == 1001) {
                    agoraMark(cityMapCopy, cury - 1, curx, currentRange, xCoor, yCoor, currentCoordinate);
                }
            }
            //rightside of the current point
            if (curx + 1 < xlength) {
                if (cityMapCopy[cury][curx + 1] == targetId) {
                    result++;
                    paintBuilding(targetBuilding, cury, curx + 1, cityMapCopy);
                }
                if (cityMapCopy[cury][curx + 1] == 1039 || (cityMapCopy[cury][curx + 1] < 900 && cityMapCopy[cury][curx + 1] > currentRange + 1)) {
                    xCoor[currentCoordinate] = curx + 1;
                    yCoor[currentCoordinate] = cury;
                    cityMapCopy[cury][curx + 1] = currentRange + 1;
                    currentCoordinate++;
                }
                if (cityMapCopy[cury][curx + 1] == 1001) {
                    agoraMark(cityMapCopy, cury, curx + 1, currentRange, xCoor, yCoor, currentCoordinate);
                }
            }
            //bottom of the current point
            if (cury + 1 < ylength) {
                if (cityMapCopy[cury + 1][curx] == targetId) {
                    result++;
                    paintBuilding(targetBuilding, cury + 1, curx, cityMapCopy);
                }
                if (cityMapCopy[cury + 1][curx] == 1039 || (cityMapCopy[cury + 1][curx] < 900 && cityMapCopy[cury + 1][curx] > currentRange + 1)) {
                    xCoor[currentCoordinate] = curx;
                    yCoor[currentCoordinate] = cury + 1;
                    cityMapCopy[cury + 1][curx] = currentRange + 1;
                    currentCoordinate++;
                }
                if (cityMapCopy[cury + 1][curx] == 1001) {
                    agoraMark(cityMapCopy, cury + 1, curx, currentRange, xCoor, yCoor, currentCoordinate);
                }
            }
            //lefthandside of the currentt point
            if (curx - 1 >= 0) {
                if (cityMapCopy[cury][curx - 1] == targetId) {
                    result++;
                    paintBuilding(targetBuilding, cury, curx - 1, cityMapCopy);
                }
                if (cityMapCopy[cury][curx - 1] == 1039 || (cityMapCopy[cury][curx - 1] < 900 && cityMapCopy[cury][curx - 1] > currentRange + 1)) {
                    xCoor[currentCoordinate] = curx - 1;
                    yCoor[currentCoordinate] = cury;
                    cityMapCopy[cury][curx - 1] = currentRange + 1;
                    currentCoordinate++;
                }
                if (cityMapCopy[cury][curx - 1] == 1001) {
                    agoraMark(cityMapCopy, cury, curx - 1, currentRange, xCoor, yCoor, currentCoordinate);
                }
            }
            curx = xCoor[queueTrace];
            cury = yCoor[queueTrace];
            queueTrace++;
            currentRange = cityMapCopy[cury][curx];
        }
        return result;
    }

    //returns number of target building instances around the building 
    //instance given by x y coordinates ; needs to be implemented
    public int numberOfInstancesAroundAnInstance(int x, int y, int[][] cityMap, Building targetBuilding, int range) {
        int targetId = targetBuilding.getId();

        int[][] cityMapCopy = new int[cityMap.length][cityMap[0].length];
        for (int i = 0; i < cityMap.length; i++) {
            System.arraycopy(cityMap[i], 0, cityMapCopy[i], 0, cityMap[i].length);
        }
        return numberOfInstancesAroundAnInstanceWithoutCopyArray(x, y, cityMapCopy, targetBuilding, range);
    }

    private void paintBuilding(Building building, int y2, int x2, int[][] cityMap) {
        //Paints the building to 901 or any other number that is not a particular number and over 900
        int ins = building.findInstance(x2, y2);
        int xMost, yMost, xStart, yStart;
        xStart = building.getInstances().get(ins).getxCoordinate();
        yStart = building.getInstances().get(ins).getyCoordinate();
        if (building.getInstances().get(ins).isHorizontal()) {
            xMost = xStart + building.getWidth();
            yMost = yStart + building.getHeight();
        } else {
            xMost = xStart + building.getHeight();
            yMost = yStart + building.getWidth();
        }
        for (int i = yStart; i < yMost; i++) {
            for (int j = xStart; j < xMost; j++) {
                cityMap[i][j] = 901;
            }
        }
    }

    //basic deletion, needs to be overwritten in some subclasses    
    public void delete(int x, int y, int[][] cityMap) {
        int i = findInstance(x, y);
        instances.remove(i);
        updateBonuses(cityMap, this, -1);
        for (Building relatedBuilding : relatedBuildings) {
            relatedBuilding.updateBonuses(cityMap, this, -1);
        }
    }

    //basic upgrade, needs to be overwiritten in some subclasses 
    public int upgrade(int x, int y) {
        int i = findInstance(x, y);
        instances.get(i).levelUp();
        return i;
    }

    //basic build, probably there is no need to overwrite
    //but might be neede in classes where there is a parallel array to the instances
    public void build(int x, int y, boolean alignment) {
        Specification spec = new Specification(x, y, constructionDuration, alignment);
        instances.add(spec);
        if (canBuiltOnlyOnce) {
            unlocked = false;
        }
    }

    public void setUnlocked(boolean unlocked) {
        this.unlocked = unlocked;
    }

    public boolean doesExist() {
        return instances.size()!=0&&instances.get(0).isFinished();
    }

    public int getCost() {
        return cost;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public int getConstructionDuration() {
        return constructionDuration;
    }

    public int getId() {
        return id;
    }

    public int getMaximumAvailableLevel() {
        return maximumAvailableLevel;
    }

    public String getName() {
        return name;
    }

    public int[] getRequiredBuildings() {
        return requiredBuildings;
    }

    public int[] getRequirementsRange() {
        return requirementsRange;
    }

    public boolean isCanBuiltOnlyOnce() {
        return canBuiltOnlyOnce;
    }

    public boolean isUnlocked() {
        return unlocked;
    }

    public ArrayList<Building> getRelatedBuildings() {
        return relatedBuildings;
    }

    public ArrayList<Specification> getInstances() {
        return instances;
    }

    public boolean isRequirementDependOnlyOnAge() {
        return requirementDependOnlyOnAge;
    }

    public void setRequirementDependOnlyOnAge(boolean requirementDependOnlyOnAge) {
        this.requirementDependOnlyOnAge = requirementDependOnlyOnAge;
    }

    public int getRequirementAge() {
        return requirementAge;
    }

    public void setRequirementAge(int requirementAge) {
        this.requirementAge = requirementAge;
    }

    public void setId(int id) {
        this.id = id;
    }

}
