/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameElementClasses;

/**
 *
 * @author onur
 */
import java.util.ArrayList;
public class Shipyard extends WorkBuilding{

    private final ArrayList<Boolean> producing;
    
    public Shipyard(int cost, int width, int height, int constructionDuration, int id, int upgradeCost1, int upgradeCost2, int maximumAvailableLevel, String name, int[] requiredBuildings, int[] requirementsRange, boolean canBuiltOnlyOnce, int[][] workerCounts) {
        super(cost, width, height, constructionDuration, id, upgradeCost1, upgradeCost2, maximumAvailableLevel, name, requiredBuildings, requirementsRange, canBuiltOnlyOnce, workerCounts);
        producing=new ArrayList();
    }
    
    public int getTotalParallelProduction(){
        int total=0;
        for(int i=0;i<getInstances().size();i++)
            if(getInstances().get(i).isFinished())
                total++;
        return total;
    }
    public int getProductionTime(Ship ship){
        for(int i=0;i<producing.size();i++)
            if(!producing.get(i)&&getInstances().get(i).getLevel()==2){
                producing.set(i, Boolean.TRUE);
                return (ship.getTrainingTime()+1)/2;
            }
        return ship.getTrainingTime();
    }
    
    public void freeShipyard(boolean isEffective){
        for(int i=0;i<getInstances().size();i++)
            if(isEffective&&getInstances().get(i).getLevel()==2&&producing.get(i)){
                producing.set(i, false);
                return;
            }
            else if(!isEffective&&getInstances().get(i).getLevel()==1&&producing.get(i)){
                producing.set(i, false);
                return;
            }
    }

    @Override
    public void delete(int x, int y, int[][] cityMap) {
        int i=findInstance(x,y);
        producing.remove(i);
        super.delete(x, y, cityMap); 
    }

    @Override
    public void build(int x, int y, boolean alignment) {
        producing.add(false);
        super.build(x, y, alignment); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    
    private int getLevelThreeInstances(){
        int t=0;
        for(int i=0; i<getInstances().size();i++)
            if(getInstances().get(i).getLevel()==2)
                t++;
        return t;
    }
}
