package gameengine.GameElementClasses;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author onur
 */
public abstract class HousingBuilding extends Building {
    private final int[] housingPerLevel;
    private final int[] housingHappinessPerLevel;

    public HousingBuilding(int[] housingPerLevel, int[] housingHappinessPerLevel, int cost, int width, int height, int constructionDuration, int id, int maximumAvailableLevel, String name, int[] requiredBuildings, int[] requirementsRange, boolean canBuiltOnlyOnce) {
        super(cost, width, height, constructionDuration, id, maximumAvailableLevel, name, requiredBuildings, requirementsRange, canBuiltOnlyOnce);
        
        this.housingPerLevel = housingPerLevel;
        this.housingHappinessPerLevel = housingHappinessPerLevel;
    }
    
    
    //returns the housing provided by instance specified by coordinates
    public int getInstanceHousing(int x, int y){
        int i=findInstance(x,y);
        return housingPerLevel[getInstances().get(i).getLevel()-1];
    }
    
    public int getTotalHousing(){
        int total=0;
        for(int i=0;i<getInstances().size();i++)
            total +=housingPerLevel[getInstances().get(i).getLevel()-1];
        return total;
    }
    
    
    public int getHappinessFromHousing(){
        int total=0;
        for(int i=0;i<getInstances().size();i++)
            total +=housingHappinessPerLevel[getInstances().get(i).getLevel()-1];
        return total/60;
    }
    
}
