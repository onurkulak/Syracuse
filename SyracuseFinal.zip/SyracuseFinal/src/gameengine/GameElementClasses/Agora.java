/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameElementClasses;

/**
 *
 * @author onur
 */
public class Agora extends Building {

    public Agora(int cost, int width, int height, int constructionDuration, int id, int upgradeCost1, int upgradeCost2, int maximumAvailableLevel, String name, int[] requiredBuildings, int[] requirementsRange, boolean canBuiltOnlyOnce) {
        super(cost, width, height, constructionDuration, id, maximumAvailableLevel, name, requiredBuildings, requirementsRange, canBuiltOnlyOnce);
    }

    @Override
    public void updateBonuses(int[][] cityMap, Building caller, int buildingInstance) {
        StorageBuilding callerS = (StorageBuilding) caller;
        if(buildingInstance!=-1)
            if(doesExist())
                if(instancesTouching(0, callerS, buildingInstance))
                    if(instanceNotIncluded(callerS, buildingInstance))
                        callerS.getNearAgoraInstances().add(buildingInstance);
    }

    private boolean instanceNotIncluded(StorageBuilding callerS, int buildingInstance) {
        for(int i=0; i<callerS.getNearAgoraInstances().size();i++)
            if(callerS.getNearAgoraInstances().get(i)==buildingInstance)
                return false;
        return true;
    }
}
