/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameElementClasses;

/**
 *
 * @author onur
 */
public class Dock extends WorkBuilding{

    public Dock(int cost, int width, int height, int constructionDuration, int id, int upgradeCost1, int upgradeCost2, int maximumAvailableLevel, String name, int[] requiredBuildings, int[] requirementsRange, boolean canBuiltOnlyOnce, int[][] workerCounts) {
        super(cost, width, height, constructionDuration, id, upgradeCost1, upgradeCost2, maximumAvailableLevel, name, requiredBuildings, requirementsRange, canBuiltOnlyOnce, workerCounts);
    }
    
    public int getTotalShipCount(){
        if(!doesExist())
            return 0;
        if(getInstances().get(0).getLevel()==1)
            return 2;
        else if(getInstances().get(0).getLevel()==2)
            return 4;
        else return 6;
    }
}
