/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameElementClasses;

/**
 *
 * @author onur
 */

import java.util.ArrayList;
public class Temple extends WorkBuilding{
    //values will be given later
    private final int RANGE=60, MARBLE_COST=2500, 
            HAPPINESS_FROM_MONUMENT=1, HAPPINESS_FROM_SHRINE=1;
    private final ArrayList<Integer> monumentNumberCovered, shrineNumberCovered;
    private int mansionsCoveredByTemples=0;
    private final int TEMPLE_HAPPINESS=1;
    public Temple(int cost, int width, int height, int constructionDuration, int id, int upgradeCost1, int upgradeCost2, int maximumAvailableLevel, String name, int[] requiredBuildings, int[] requirementsRange, boolean canBuiltOnlyOnce, int[][] workerCounts) {
        super(cost, width, height, constructionDuration, id, upgradeCost1, upgradeCost2, maximumAvailableLevel, name, requiredBuildings, requirementsRange, canBuiltOnlyOnce, workerCounts);
        monumentNumberCovered=new ArrayList();
        shrineNumberCovered=new ArrayList();
    }

    public int getTotalHappıness(){
        int total=0;
        for(int i=0; i<getInstances().size();i++)
            if(getInstances().get(i).getLevel()==3){
                total+=monumentNumberCovered.get(i)*HAPPINESS_FROM_MONUMENT+
                        shrineNumberCovered.get(i)*HAPPINESS_FROM_SHRINE;
            }
            else if(getInstances().get(i).getLevel()==2)
                total+=shrineNumberCovered.get(i)*HAPPINESS_FROM_SHRINE;
        return total/3+getHappinessFromTemples();
    }
    
    @Override
    public void delete(int x, int y, int[][] cityMap){
        int p=findInstance(x,y);
        monumentNumberCovered.remove(p);
        shrineNumberCovered.remove(p);
        super.delete(x, y, cityMap);
    }
    
    public int getHappinessFromTemples(){
        return mansionsCoveredByTemples*TEMPLE_HAPPINESS/10;
    }

    @Override
    public void build(int x, int y, boolean alignment) {
        monumentNumberCovered.add(0);
        shrineNumberCovered.add(0);
        super.build(x, y, alignment); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    public int getMARBLE_COST() {
        return MARBLE_COST;
    }


    @Override 
    public void updateBonuses(int[][] cityMap, Building caller, int buildingInstance) {
        if(caller.getName().equals("Temple")||caller.getName().equals("Mansion")){
            mansionsCoveredByTemples=0;
            int[][] cityMapCopy=new int[cityMap.length][cityMap[0].length];
            for(int i=0;i<cityMap.length;i++)
                System.arraycopy(cityMap[i], 0, cityMapCopy[i], 0, cityMap[i].length);
            
            for(int i=0;i<getInstances().size();i++)
                if(getInstances().get(i).isFinished())
                    mansionsCoveredByTemples+=numberOfInstancesAroundAnInstanceWithoutCopyArray
        (getInstances().get(i).getxCoordinate(), getInstances().get(i).getyCoordinate(), cityMapCopy, getRelatedBuildings().get(2), RANGE);
        }
        else if(caller.getName().equals("Monument")){
            for(int i=0;i<getInstances().size();i++)
                if(getInstances().get(i).isFinished())
                    monumentNumberCovered.set(i, numberOfInstancesAroundAnInstance(getInstances().get(i).getxCoordinate(), getInstances().get(i).getyCoordinate(), cityMap, getRelatedBuildings().get(0), RANGE));
        }
        else if(caller.getName().equals("Shrine")){
            for(int i=0;i<getInstances().size();i++)
                if(getInstances().get(i).isFinished())
                    monumentNumberCovered.set(i, numberOfInstancesAroundAnInstance(getInstances().get(i).getxCoordinate(), getInstances().get(i).getyCoordinate(), cityMap, getRelatedBuildings().get(1), RANGE));
        }
    }
    
    
    
}
