/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameElementClasses;

/**
 *
 * @author onur
 */
import java.util.ArrayList;

public class LandUnit extends Unit {

    //attributes of a unit

    private final boolean mounted, melee, armored;
    //bonuses of a unit type
    private final double cityDefenceBonus, againstUnarmoredBonus,
            againstArmouredMeleeInfantryBonus, againstMeleeInfantryBonus,
            againstMountedBonus, againstUnarmoredMeleeInfantryBonus,
            swarmBonus, againstRangedBonus, cityRaiderBonus, elephantEffectBonus,
            cavalrySuperiorityBonus;
    private final int spearArrowCost, swordCost, horseCost, armorCost;

    public LandUnit(boolean mounted, boolean melee, boolean armored, double cityDefenceBonus, double againstUnarmoredBonus, double againstArmouredMeleeInfantryBonus, double againstMeleeInfantryBonus, double againstMountedBonus, double againstUnarmoredMeleeInfantryBonus, double swarmBonus, double againstRangedBonus, double cityRaiderBonus, double elephantEffectBonus, double cavalrySuperiorityBonus, int spearArrowCost, int swordCost, int horseCost, int armorCost, int proletariatRequirement, int aristoiRequirement, int moneyCost, int trainingTime, int monthlyWage, int basePower, String name) {
        super(proletariatRequirement, aristoiRequirement, moneyCost, trainingTime, monthlyWage, basePower, name);
        this.mounted = mounted;
        this.melee = melee;
        this.armored = armored;
        this.cityDefenceBonus = cityDefenceBonus;
        this.againstUnarmoredBonus = againstUnarmoredBonus;
        this.againstArmouredMeleeInfantryBonus = againstArmouredMeleeInfantryBonus;
        this.againstMeleeInfantryBonus = againstMeleeInfantryBonus;
        this.againstMountedBonus = againstMountedBonus;
        this.againstUnarmoredMeleeInfantryBonus = againstUnarmoredMeleeInfantryBonus;
        this.swarmBonus = swarmBonus;
        this.againstRangedBonus = againstRangedBonus;
        this.cityRaiderBonus = cityRaiderBonus;
        this.elephantEffectBonus = elephantEffectBonus;
        this.cavalrySuperiorityBonus = cavalrySuperiorityBonus;
        this.spearArrowCost = spearArrowCost;
        this.swordCost = swordCost;
        this.horseCost = horseCost;
        this.armorCost = armorCost;
    }

    //needs to be implemented
    //if is attacking and siege battle city raider bonus applied
    //if siege and defending city defence bonus applied
    //if siege battle mounted units don't get bonuses
    //if the [1] element in first array hoplite and [1] on the other array is 350 that means army includes 350 hoplites etc.
    //if enemy's number of cavalries is less than the unit's count cavalrySuperiorityBonus applied
    //if unit has swarmbonus and count is more than 1000 swarmbonus applies 
    //if enemy unit has no "againstmountedbonus" elephant effect bonus applies
    // every bonus is a double value
    //say enemy army units are 1/3 ranged then
    //(1/3)*againstRangedBonus is added to the total bonus of the unit
    //againstBlabla bonuses are applied like above example, 
    //portion of the enemy army that fits the description*bonus value
    //in the end method returns basePower*count*(1+totalBonus)
    //getBasePower() is an inherited method, returns basepower
    public double getPowerAfterBonusesApplied(int count, ArrayList<LandUnit> enemyArmyUnits,
            ArrayList<Integer> enemyArmyUnitCounts, boolean isAttacking, boolean isSiegeBattle) {
        double bonus = 0.0;
        int totalEnemy = 0;
        for (int i = 0; i < enemyArmyUnits.size(); i++) {
            totalEnemy = totalEnemy + enemyArmyUnitCounts.get(i);
        }
        if ((isSiegeBattle) && (isAttacking)) {
            bonus = bonus + cityRaiderBonus;
        }
        if ((isSiegeBattle) && !(isAttacking)) {
            bonus = bonus + cityDefenceBonus;
        }
        if (totalEnemy < count) {
            bonus = bonus + cavalrySuperiorityBonus;
        }
        if (againstMountedBonus == 0) {
            bonus = bonus + elephantEffectBonus;
        }
        if (againstUnarmoredBonus != 0.0) {
            int noOfnotArmored = 0;
            for (int i = 0; i < enemyArmyUnits.size(); i++) {
                if (!(enemyArmyUnits.get(i).armored)) {
                    noOfnotArmored = noOfnotArmored + enemyArmyUnitCounts.get(i);
                }
            }
            bonus = bonus + againstUnarmoredBonus * (noOfnotArmored / totalEnemy);
        }
        if (againstArmouredMeleeInfantryBonus != 0.0) {
            int noOfArmoredMelee = 0;
            for (int i = 0; i < enemyArmyUnits.size(); i++) {
                if ((enemyArmyUnits.get(i).melee) && (enemyArmyUnits.get(i).armored) && (!enemyArmyUnits.get(i).mounted)) {
                    noOfArmoredMelee = noOfArmoredMelee + enemyArmyUnitCounts.get(i);
                }
            }
            bonus = bonus + againstArmouredMeleeInfantryBonus * (noOfArmoredMelee / totalEnemy);
        }
        if (againstMeleeInfantryBonus != 0.0) {
            int noOfMelee = 0;
            for (int i = 0; i < enemyArmyUnits.size(); i++) {
                if (enemyArmyUnits.get(i).melee) {
                    noOfMelee = noOfMelee + enemyArmyUnitCounts.get(i);
                }
            }
            bonus = bonus + againstMeleeInfantryBonus * (noOfMelee / totalEnemy);
        }
        if (againstUnarmoredMeleeInfantryBonus != 0.0) {
            int noOfUnarmoredMelee = 0;
            for (int i = 0; i < enemyArmyUnits.size(); i++) {
                if ((enemyArmyUnits.get(i).melee) && !(enemyArmyUnits.get(i).armored) && !(enemyArmyUnits.get(i).mounted)) {
                    noOfUnarmoredMelee = noOfUnarmoredMelee + enemyArmyUnitCounts.get(i);
                }
            }
            bonus = bonus + againstUnarmoredMeleeInfantryBonus * (noOfUnarmoredMelee / totalEnemy);
        }
        if (againstRangedBonus != 0.0) {
            int noOfRanged = 0;
            for (int i = 0; i < enemyArmyUnits.size(); i++) {
                if (!(enemyArmyUnits.get(i).melee)) {
                    noOfRanged = noOfRanged + enemyArmyUnitCounts.get(i);
                }
            }
            bonus = bonus + againstRangedBonus * (noOfRanged / totalEnemy);
        }
        if ((againstMountedBonus != 0.0) && !(isSiegeBattle)) {
            int noOfMounted = 0;
            for (int i = 0; i < enemyArmyUnits.size(); i++) {
                if (enemyArmyUnits.get(i).mounted) {
                    noOfMounted = noOfMounted + enemyArmyUnitCounts.get(i);
                }
            }
            bonus = bonus + againstMountedBonus * (noOfMounted / totalEnemy);

        }

        return super.getBasePower() * count * (1 + bonus);
    }

    public int getSpearArrowCost() {
        return spearArrowCost;
    }

    public int getSwordCost() {
        return swordCost;
    }

    public int getHorseCost() {
        return horseCost;
    }

    public int getArmorCost() {
        return armorCost;
    }

    
}

