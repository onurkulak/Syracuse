/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameElementClasses;

/**
 *
 * @author onur
 */
public abstract class LandProvince extends Province{
    private Army army;
    
    private LandProvince[] neighbors;
    private Faction owner;
    public Faction getOwner() {
        return owner;
    }

    public void setOwner(Faction owner) {
        this.owner = owner;
    }

    public LandProvince(String name) {
        super(name);
        army=null;
    }

    public Army getArmy() {
        return army;
    }

    public void setArmy(Army army) {
        this.army = army;
    }

    public LandProvince[] getNeighbors() {
        return neighbors;
    }

    public void setNeighbors(LandProvince[] neighbors) {
        this.neighbors = neighbors;
    }
    
}
