/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameManagers;

import CurrentGameMemory.Game;
import gameengine.GameElementClasses.Building;
import gameengine.GameElementClasses.Specification;
import gameengine.GameElementClasses.WorkBuilding;

/**
 *
 * @author onur
 */
public class BuildingManager extends Manager {

    public BuildingManager(Game game) {
        super(game);
    }

    public boolean build(Building building, int xCoor, int yCoor, boolean horizontal) {
        if (isBuildable(building, xCoor, yCoor, horizontal)) {
            payCosts(building);
            paintMap(building, xCoor, yCoor, horizontal);
            building.build(xCoor, yCoor, horizontal);
            employPeople(building);
            return true;
        } else {
            return false;
        }
    }
    
    public void updateConstructions(){
        if(!game.getCityStatus().isThereAnarchy())
            for (Building allBuilding : game.getBuildings().getAllBuildings()) {
            allBuilding.passTurn(game.getCityMap());
        }
    }
    
    public void delete(int x, int y){
        Building building = getBuilding( x, y);
        if (building!=null){
            deletionPaint(x,y,building);
            if(isWorkBuilding(building)){
                WorkBuilding wb=(WorkBuilding) building;
                game.getPeople().getAristoi().adjustUnemployedPopulation(wb.getRequiredAristoi(x, y));
                game.getPeople().getProletariat().adjustUnemployedPopulation(wb.getRequiredProletariat(x, y));
            }
            building.delete(x, y, game.getCityMap());
            
        }
    }
    
    private boolean isPossibleToUpdate(Building building, int x, int y){
        if(building.getRequirementAge()<game.getAge()){
            int i=building.findInstance(x,y);
            if(building.getInstances().get(i).getLevel()+building.getRequirementAge()-1<game.getAge()&&building.getInstances().get(i).getLevel()<building.getMaximumAvailableLevel()){
                if(game.getMoney()>=building.getCost()){
                    if(isWorkBuilding(building)){
                        int upLevel = building.getInstances().get(i).getLevel()+1;
                        WorkBuilding wb = (WorkBuilding) building;
                        if(wb.getRequiredAristoiAfterUpgrade(upLevel)>game.getPeople().getAristoi().getUnemployed())
                            return false;
                        if(wb.getRequiredProletariatAfterUpgrade(upLevel)>game.getPeople().getProletariat().getUnemployed())
                            return false;
                    }
                }
                else return false;
            }else return false;
        }else return false;
    return true;
    }
    
    public void updateBuilding(int x, int y){
        Building building = getBuilding( x, y);
        if (building!=null){
            if(isPossibleToUpdate(building, x, y)){
                upgrade(building,x,y);
            }
        }
    }
    
    //uses citymap to find building, returns false if the square is empty or sea or wall
    private Building getBuilding(int x, int y){
        int id=game.getCityMap()[y][x];
        if(id<1000)
        {
            return null;
        }
        else{
            return  game.getBuildings().getAllBuildings()[id-1000];
        }
    }
    
    public void unlockBuildings(){
        game.getBuildings().getGlassMaker().setUnlocked(game.getPlaces().getLilybaeumProvince().getOwner()==game.getFaction());
    }

    public boolean isBuildable(Building building, int xCoor, int yCoor, boolean horizontal) {
        if (!building.isUnlocked() || game.getCityStatus().isThereAnarchy()) {
            return false;
        }
        if (!checkCollision(building, xCoor, yCoor, horizontal)) {
            return false;
        }
        if (!checkRequiredBuildings(building, xCoor, yCoor, horizontal)) {
            return false;
        }
        if (!isThereEnoughManpower(building)) {
            return false;
        }
        return checkCosts(building);
    }

    private boolean checkRequiredBuildings(Building building, int xCoor, int yCoor, boolean horizontal) {
        building.getInstances().add(new Specification(xCoor, yCoor, 0, horizontal));
        boolean isThere = true;
        for (int i = 0; i < building.getRequiredBuildings().length; i++) {
            if (!building.isThereInstanceNearby(xCoor, yCoor, building.getRequiredBuildings()[i], building.getRequirementsRange()[i], game.getCityMap())) {
                isThere = false;
                break;
            }
        }
        building.getInstances().remove(building.getInstances().size() - 1);
        return isThere;
    }

    private boolean checkCollision(Building building, int xCoor, int yCoor, boolean horizontal) {

        int width, height;
        if (horizontal) {
            width = building.getWidth();
            height = building.getHeight();
        } else {
            height = building.getWidth();
            width = building.getHeight();
        }
        for (int i = yCoor; i < yCoor + height; i++) {
            for (int j = xCoor; j < xCoor + width; j++) {
                if (game.getCityMap()[i][j] != 999) {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean checkCosts(Building building) {
        if (game.getMoney() < getBuildingCost(building)) {
            return false;
        }
        if (building == game.getBuildings().getColossus() && game.getBuildings().getColossus().getCOPPER_COST() > game.getMaterials().getCopper().getAmount()) {
            return false;
        } else if (building == game.getBuildings().getParthenon() && game.getBuildings().getParthenon().getMARBLE_COST() > game.getMaterials().getMarble().getAmount()) {
            return false;
        } else if (building == game.getBuildings().getStatueOfZeus() && (game.getBuildings().getStatueOfZeus().getGOLD_COST() > game.getMaterials().getGold().getAmount() || game.getBuildings().getStatueOfZeus().getIVORY_COST() > game.getMaterials().getIvory().getAmount())) {
            return false;
        } else if (building == game.getBuildings().getTemple() && game.getBuildings().getTemple().getMARBLE_COST() > game.getMaterials().getProcessedMarble().getAmount()) {
            return false;
        }
        return true;
    }

    //%5 discount if running tyranny
    private int getBuildingCost(Building building) {
        if (game.getPlayerCivics().getGovCiv().getName().equals("Tyranny")) {
            return building.getCost() * 95 / 100;
        } else {
            return building.getCost();
        }
    }

    private void payCosts(Building building) {
        game.pay(getBuildingCost(building));
        if (building == game.getBuildings().getColossus()) {
            game.getMaterials().getCopper().consume(game.getBuildings().getColossus().getCOPPER_COST());
        } else if (building == game.getBuildings().getParthenon()) {
            game.getMaterials().getProcessedMarble().consume(game.getBuildings().getParthenon().getMARBLE_COST());
        } else if (building == game.getBuildings().getStatueOfZeus()) {
            game.getMaterials().getIvory().consume(game.getBuildings().getStatueOfZeus().getIVORY_COST());
            game.getMaterials().getGold().consume(game.getBuildings().getStatueOfZeus().getGOLD_COST());
        } else if (building == game.getBuildings().getTemple()) {
            game.getMaterials().getProcessedMarble().consume(game.getBuildings().getTemple().getMARBLE_COST());
        }
    }

    private void paintMap(Building building, int xCoor, int yCoor, boolean horizontal) {
        int xMost, yMost;
        if(horizontal){
            xMost=xCoor+building.getWidth();
            yMost=yCoor+building.getHeight();
        }
        else{
            xMost=xCoor+building.getHeight();
            yMost=yCoor+building.getWidth();
        }
        
        while(yCoor<yMost){
            while(xCoor<xMost){
                game.getCityMap()[yCoor][xCoor]=building.getId();
                xCoor++;
            }
            yCoor++;
        }
    }

    //needs to be implemented in a fast way, don't have time for a fast way does linear search :/
    private boolean isWorkBuilding(Building building) {
        for(int i=0; i<game.getBuildings().getAllWorkBuildings().length; i++)
            if(game.getBuildings().getAllWorkBuildings()[i]==building)
                return true;
        return false;
            
    }

    private boolean isThereEnoughManpower(Building building) {
        if (isWorkBuilding(building)) {
            WorkBuilding wb = (WorkBuilding) building;
            if (wb.getRequiredAristoi(1) > game.getPeople().getAristoi().getUnemployed() || wb.getRequiredProletariat(1) > game.getPeople().getProletariat().getUnemployed()) {
                return false;
            }
        }
        return true;
    }

    private void employPeople(Building building) {
        if (isWorkBuilding(building)) {
            WorkBuilding wb = (WorkBuilding) building;
            game.getPeople().getAristoi().adjustUnemployedPopulation(-wb.getRequiredAristoi(1));
            game.getPeople().getProletariat().adjustUnemployedPopulation(-wb.getRequiredProletariat(1));
        }
    }

    private void upgrade(Building building, int x, int y) {
        game.pay(building.getCost());
        int i = building.findInstance(x, y);
        int level = building.getInstances().get(i).getLevel()+1;
        building.getInstances().get(i).levelUp();
        if(isWorkBuilding(building)){
            WorkBuilding wb=(WorkBuilding) building;
            game.getPeople().getAristoi().adjustUnemployedPopulation(-wb.getRequiredAristoiAfterUpgrade(level));
            game.getPeople().getProletariat().adjustUnemployedPopulation(-wb.getRequiredProletariatAfterUpgrade(level));
        }
        
        if(building==game.getBuildings().getShrine())
            handleShrineUpgrade( x,  y);
    }

    
    //handles house instances when a shrine has upgraded
    private void handleShrineUpgrade(int x, int y) {
        
        }

    private void deletionPaint(int xCoor, int yCoor, Building building) {
        int xMost, yMost;
        boolean horizontal = building.getInstances().get(building.findInstance(xCoor, yCoor)).isHorizontal();
        if(horizontal){
            xMost=xCoor+building.getWidth();
            yMost=yCoor+building.getHeight();
        }
        else{
            xMost=xCoor+building.getHeight();
            yMost=yCoor+building.getWidth();
        }
        
        while(yCoor<yMost){
            while(xCoor<xMost){
                game.getCityMap()[yCoor][xCoor]=999;
                xCoor++;
            }
            yCoor++;
        }
    }
}
