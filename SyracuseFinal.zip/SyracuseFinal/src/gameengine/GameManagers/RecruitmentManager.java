/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameManagers;

import CurrentGameMemory.Game;
import gameengine.GameElementClasses.LandUnit;
import gameengine.GameElementClasses.Ship;
import gameengine.GameElementClasses.Unit;

/**
 *
 * @author onur
 */
public class RecruitmentManager extends Manager {

    public RecruitmentManager(Game game) {
        super(game);
    }

    public void recruitUnits() {
        for (int i = 0; i < game.getActiveThings().getLandQueue().size(); i++) {
            if (game.getActiveThings().getLandQueueTimes().get(i) == 1) {
                recruitLandUnit(game.getActiveThings().getLandQueue().get(i));
                game.getActiveThings().getLandQueue().remove(i);
                game.getActiveThings().getLandQueueTimes().remove(i);
                i--;
            } else {
                game.getActiveThings().getLandQueueTimes().set(i, game.getActiveThings().getLandQueueTimes().get(i) - 1);
            }
        }

        for (int i = 0; i < game.getActiveThings().getShipQueue().size(); i++) {
            if (game.getActiveThings().getShipQueueTimes().get(i) == 1) {
                recruitShip(game.getActiveThings().getShipQueue().get(i));
                game.getActiveThings().getShipQueue().remove(i);
                game.getActiveThings().getShipQueueTimes().remove(i);
                game.getBuildings().getShipyard().freeShipyard(game.getActiveThings().getUsingEffectiveShipyard().get(i));
                game.getActiveThings().getUsingEffectiveShipyard().remove(i);
                i--;
            } else {
                game.getActiveThings().getShipQueueTimes().set(i, game.getActiveThings().getLandQueueTimes().get(i) - 1);
            }
        }
    }

    private void recruitLandUnit(LandUnit unit) {
        int totalMan = unit.getAristoiRequirement() + unit.getProletariatRequirement();
        for (int i = 0; i < game.getFaction().getSyracuse().getGarrison().getUnits().size(); i++) {
            if (unit == game.getFaction().getSyracuse().getGarrison().getUnits().get(i)) {
                game.getFaction().getSyracuse().getGarrison().getUnitCounts().set(i, game.getFaction().getSyracuse().getGarrison().getUnitCounts().get(i) + totalMan);
                return;
            }
        }
        game.getFaction().getSyracuse().getGarrison().getUnits().add(unit);
        game.getFaction().getSyracuse().getGarrison().getUnitCounts().add(totalMan);
    }

    private void recruitShip(Ship unit) {
        for (int i = 0; i < game.getFaction().getSyracuse().getGarrison().getShips().size(); i++) {
            if (game.getFaction().getSyracuse().getGarrison().getShips().get(i) == unit) {
                game.getFaction().getSyracuse().getGarrison().getShipCounts().set(i, 1 + game.getFaction().getSyracuse().getGarrison().getShipCounts().get(i));
                return;
            }
        }
        game.getFaction().getSyracuse().getGarrison().getShipCounts().add(1);
        game.getFaction().getSyracuse().getGarrison().getShips().add(unit);
    }

    public void orderNewLandRecruitments(LandUnit[] landUnits) {
        if (checkUnlocked(landUnits)) {
            int proletariatReq = 0, aristoiReq = 0,
                    spearArrowReq = 0, swordReq = 0, horseReq = 0, armorReq = 0, moneyReq = 0;

            for (LandUnit landUnit : landUnits) {
                proletariatReq += landUnit.getProletariatRequirement();
                aristoiReq += landUnit.getAristoiRequirement();
                spearArrowReq += landUnit.getSpearArrowCost();
                swordReq += landUnit.getSwordCost();
                horseReq += landUnit.getHorseCost();
                armorReq += landUnit.getArmorCost();
                moneyReq += landUnit.getMoneyCost();
            }

            if (proletariatReq <= game.getPeople().getProletariat().getUnemployed()
                    && aristoiReq <= game.getPeople().getAristoi().getUnemployed()
                    && spearArrowReq <= game.getMaterials().getSpearArrow().getAmount()
                    && swordReq <= game.getMaterials().getSword().getAmount()
                    && horseReq <= game.getMaterials().getHorse().getAmount()
                    && armorReq <= game.getMaterials().getArmour().getAmount()
                    && moneyReq <= game.getMoney()) {
                game.getMaterials().getSword().consume(swordReq);
                game.getMaterials().getHorse().consume(horseReq);
                game.getMaterials().getArmour().consume(armorReq);
                game.getMaterials().getSpearArrow().consume(spearArrowReq);
                game.pay(moneyReq);
                game.getPeople().getProletariat().adjustUnemployedPopulation(-proletariatReq);
                game.getPeople().getAristoi().adjustUnemployedPopulation(-aristoiReq);
                addToLandUnits(landUnits);
            }

        }
    }

    public void orderNewShips(Ship[] ships) {
        if(checkUnlocked(ships)){
            int lumberReq=0, slaveReq=0, proReq=0, moneyReq=0, ariReq=0;
            
            for (Ship ship : ships) {
                lumberReq+=ship.getLumberRequirement();
                slaveReq+=ship.getSlaveRequirement();
                proReq+=ship.getProletariatRequirement();
                ariReq+=ship.getAristoiRequirement();
                moneyReq+=ship.getMoneyCost();
            }
            
            if(lumberReq<=game.getMaterials().getLumber().getAmount()
                    &&ariReq<=game.getPeople().getAristoi().getUnemployed()
                    &&proReq<=game.getPeople().getProletariat().getUnemployed()
                    &&moneyReq<=game.getMoney()
                    &&slaveReq<=game.getPeople().getSlaves().getUnemployed()
                    &&ships.length+game.getActiveThings().getShipQueue().size()<=
                    game.getBuildings().getShipyard().getTotalParallelProduction()){
                game.getMaterials().getLumber().consume(lumberReq);
                game.getPeople().getAristoi().adjustUnemployedPopulation(-ariReq);
                game.getPeople().getSlaves().adjustUnemployedPopulation(-slaveReq);
                game.getPeople().getProletariat().adjustUnemployedPopulation(-proReq);
                game.pay(moneyReq);
                addToShips(ships);
            }
            
            
        }
    }

    private boolean checkUnlocked(Unit[] units) {
        for (int i = 0; i < units.length; i++) {
            if (!units[i].isUnlocked()) {
                return false;
            }
        }
        return true;
    }

    private void addToLandUnits(LandUnit[] landUnits) {
        for (LandUnit landUnit : landUnits) {
            game.getActiveThings().getLandQueue().add(landUnit);
            game.getActiveThings().getLandQueueTimes().add(landUnit.getTrainingTime());
        }
    }

    private void addToShips(Ship[] ships) {
        for (Ship ship : ships) {
            game.getActiveThings().getShipQueue().add(ship);
            int normalTrainingTime = ship.getTrainingTime();
            game.getActiveThings().getShipQueueTimes().add(game.getBuildings().getShipyard().getProductionTime(ship));
            if(normalTrainingTime==game.getActiveThings().getShipQueueTimes().get(game.getActiveThings().getShipQueueTimes().size()-1))
                game.getActiveThings().getUsingEffectiveShipyard().add(false);
            else
                game.getActiveThings().getUsingEffectiveShipyard().add(true);
        }
    }
    
    public void unlockUnits(){
        game.getUnits().getHoplite().setUnlocked(game.getBuildings().getBarrack().doesExist());
        game.getUnits().getSlinger().setUnlocked(game.getBuildings().getBarrack().doesExist());
        game.getUnits().getToxotes().setUnlocked(game.getBuildings().getArcheryRange().doesExist());
        game.getUnits().getPeltast().setUnlocked(game.getBuildings().getArcheryRange().doesExist());
        game.getUnits().getPhalangite().setUnlocked(game.getBuildings().getBarrack().getInstances().get(0).isFinished()&&2==game.getBuildings().getBarrack().getInstances().get(0).getLevel());
        game.getUnits().getHetairoi().setUnlocked(game.getBuildings().getStable().doesExist());
        game.getUnits().getOnager().setUnlocked(game.getBuildings().getSiegeWorkshop().doesExist());
        game.getUnits().getManipulus().setUnlocked(game.getPlaces().getMessinaProvince().getOwner()==game.getFaction());
        
    }
}
