/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameManagers;

import CurrentGameMemory.Game;
import gameengine.GameElementClasses.ManufacturedMaterial;

/**
 *
 * @author onur
 */
public class MaterialAndHappinessManager extends Manager {

    public MaterialAndHappinessManager(Game game) {
        super(game);
    }

    public void disposeOverProduction(){
        for(int i=0; i<game.getMaterials().getAllMaterials().length; i++)
            if(!game.getMaterials().getAllMaterials()[i].isStorable())
                game.getMaterials().getAllMaterials()[i].setAmount(0);
        for(int i=0; i<game.getBuildings().getAllStorageBuildings().length;i++)
            for(int j=0; j<game.getBuildings().getAllStorageBuildings()[i].getStoredResources().length;j++)
                if(game.getBuildings().getAllStorageBuildings()[i].getTotalStorageCapacities()[j]<game.getBuildings().getAllStorageBuildings()[i].getStoredResources()[j].getAmount())
                    game.getBuildings().getAllStorageBuildings()[i].getStoredResources()[j].setAmount(game.getBuildings().getAllStorageBuildings()[i].getTotalStorageCapacities()[j]);
    }
    
    public void gatherRawResources() {
        if (!game.getFaction().getSyracuse().isBesieged()) {
            for (int i = 0; i < game.getFaction().getCounties().size(); i++) {
                int amount = game.getFaction().getCounties().get(i).getResource(game.getDate());
                if (game.getFaction().getCounties().get(i).getProducedMaterial().isSeasonalMaterial() && game.getBuildings().getObservatory().doesExist()) {
                    amount *= 1.05;
                }
                if (game.getPlayer().getPlayerEconomicSetting() == 3) {
                    amount *= 1.50;
                } else if (game.getPlayer().getPlayerEconomicSetting() == 1) {
                    amount *= 0.8;
                }
                if (game.getFaction().getCounties().get(i).getProducedMaterial() == game.getMaterials().getSheep()) {
                    game.getMaterials().getMeat().increase((int) (amount * 0.2));
                    game.getMaterials().getWool().increase((int) (amount * 1.0));
                    game.getMaterials().getCheese().increase((int) (amount * 0.8));
                } else {
                    game.getFaction().getCounties().get(i).getProducedMaterial().increase(amount);
                }
            }
        }
    }

    //this need to be written along with gui also care about pointers
    public void newManufactureSettings() {

    }

    public void manufactureMaterial() {
        game.getMaterials().getPot().increase(game.getBuildings().getPotteryMaker().getTotalProductionCapacity());

        game.getMaterials().getGlass().increase(game.getBuildings().getGlassMaker().getTotalProductionCapacity());

        game.getMaterials().getFish().increase(game.getBuildings().getFishery().getTotalProductionCapacity());

        manufacturePig();
        manufactureOil();
        manufactureGrapeJuice();
        manufactureLumber();
        manufactureMarble();
        manufactureFabric();
        manufactureDyedFabric();
        manufactureCloths();
        manufactureArmour();
        manufactureIron();
        manufactureAccessory();
        manufactureFlour();
        manufactureHorse();
        manufactureWeapons();
        manufactureMeat();
        manufactureFoodThings();

    }

    public void consume() {
        boolean cityBesiege = game.getFaction().getSyracuse().isBesieged();
        game.getPeople().getAristoi().consume(cityBesiege);
        game.getPeople().getProletariat().consume(cityBesiege);
        game.getPeople().getSlaves().consume(cityBesiege);
    }

    public void paySoldiers() {
        for (int i = 0; i < game.getFaction().getGarrisons().size(); i++) {
            game.pay(game.getFaction().getGarrisons().get(i).getTotalWage());
        }
        for (int i = 0; i < game.getFaction().getArmies().size(); i++) {
            game.pay(game.getFaction().getArmies().get(i).getTotalWage());
        }
        for (int i = 0; i < game.getFaction().getNavies().size(); i++) {
            game.pay(game.getFaction().getNavies().get(i).getTotalWage());
        }

        if (game.getPlayerCivics().getMilCiv().getName().equals("Mercenaries")) {
            for (int i = 0; i < game.getFaction().getArmies().size(); i++) {
                for (int j = 0; j < game.getFaction().getArmies().get(i).getUnits().size(); j++) {
                    if (game.getFaction().getArmies().get(i).getUnits().get(j) == game.getUnits().getMercenaryhoplite()) {
                        game.addMoney(game.getFaction().getArmies().get(i).getTotalWage() / 3);
                    }
                }
            }
        }

    }

    private void produceMaximumAvailable(ManufacturedMaterial thing, int productionCapacity) {

        int smallestProductionAmount = maximumProductionAvailable(thing, productionCapacity);
        thing.increase(smallestProductionAmount);
        for (int i = 0; i < thing.getCostType().length; i++) {
            thing.getCostType()[i].consume((int) (smallestProductionAmount * thing.getCostAmount()[i]));
        }
    }

    private int maximumProductionAvailable(ManufacturedMaterial thing, int productionCapacity) {
        int smallestProductionAmount = productionCapacity;
        for (int i = 0; i < thing.getCostType().length; i++) {
            if (smallestProductionAmount * thing.getCostAmount()[i] > thing.getCostType()[i].getAmount()) {
                smallestProductionAmount = (int) (thing.getCostType()[i].getAmount() / thing.getCostAmount()[i]);
            }
        }
        return smallestProductionAmount;
    }

    private void manufactureFabric() {
        if (game.getMaterials().getFabric().getProductionLevel() != 0) {
            int maximumStorable;
            if (game.getBuildings().getFabricMerchant().getTotalProductionCapacity() < game.getBuildings().getFabricMerchant().getLeftStorageCapacity(game.getMaterials().getFabric())) {
                maximumStorable = game.getBuildings().getFabricMerchant().getTotalProductionCapacity();
            } else {
                maximumStorable = game.getBuildings().getFabricMerchant().getLeftStorageCapacity(game.getMaterials().getFabric());
            }
            if (maximumStorable < game.getMaterials().getFabric().getCostType()[0].getAmount() / game.getMaterials().getFabric().getCostAmount()[0]
                    + game.getMaterials().getFabric().getCostType()[1].getAmount() / game.getMaterials().getFabric().getCostAmount()[1]) {
                game.getMaterials().getFabric().increase(maximumStorable);

                if (game.getBuildings().getFabricMerchant().getLeftStorageCapacity(game.getMaterials().getFabric().getCostType()[0])
                        < game.getBuildings().getFabricMerchant().getLeftStorageCapacity(game.getMaterials().getFabric().getCostType()[1])) {

                    if (maximumStorable < game.getMaterials().getFabric().getCostType()[0].getAmount() / game.getMaterials().getFabric().getCostAmount()[0]) {
                        game.getMaterials().getFabric().getCostType()[0].consume((int) (maximumStorable * game.getMaterials().getFabric().getCostAmount()[0]));
                    } else {
                        maximumStorable -= (int) (game.getMaterials().getFabric().getCostType()[0].getAmount() / game.getMaterials().getFabric().getCostAmount()[0]);
                        game.getMaterials().getFabric().getCostType()[0].setAmount(0);
                        game.getMaterials().getFabric().getCostType()[1].consume((int) (maximumStorable * game.getMaterials().getFabric().getCostAmount()[1]));
                    }

                } else {
                    if (maximumStorable < game.getMaterials().getFabric().getCostType()[1].getAmount() / game.getMaterials().getFabric().getCostAmount()[1]) {
                        game.getMaterials().getFabric().getCostType()[1].consume((int) (maximumStorable * game.getMaterials().getFabric().getCostAmount()[1]));
                    } else {
                        maximumStorable -= (int) (game.getMaterials().getFabric().getCostType()[1].getAmount() / game.getMaterials().getFabric().getCostAmount()[1]);
                        game.getMaterials().getFabric().getCostType()[1].setAmount(0);
                        game.getMaterials().getFabric().getCostType()[0].consume((int) (maximumStorable * game.getMaterials().getFabric().getCostAmount()[0]));
                    }
                }
            } else {
                game.getMaterials().getFabric().increase((int) (game.getMaterials().getFabric().getCostType()[1].getAmount() / game.getMaterials().getFabric().getCostAmount()[1]
                        + game.getMaterials().getFabric().getCostType()[0].getAmount() / game.getMaterials().getFabric().getCostAmount()[0]));
                game.getMaterials().getFabric().getCostType()[0].setAmount(0);
                game.getMaterials().getFabric().getCostType()[1].setAmount(0);

            }
        }
    }

    private void manufactureDyedFabric() {
        if(game.getMaterials().getDyedFabric().getProductionLevel() != 2)
            if(game.getMaterials().getDye().consume((game.getPeople().getAristoi().getCountInCity()+game.getPeople().getAristoi().getCountInCity())/25))
                game.getBuildings().getTheatre().setUsingDye(true);
            else game.getBuildings().getTheatre().setUsingDye(false);
        else game.getBuildings().getTheatre().setUsingDye(false);    
            
        
        if (game.getMaterials().getDyedFabric().getProductionLevel() != 0) {
            int maximumStorable;
            if (game.getBuildings().getFabricMerchant().getTotalDyedFabricProductionCapacity() < game.getBuildings().getFabricMerchant().getLeftStorageCapacity(game.getMaterials().getDyedFabric())) {
                maximumStorable = game.getBuildings().getFabricMerchant().getTotalDyedFabricProductionCapacity();
            } else {
                maximumStorable = game.getBuildings().getFabricMerchant().getLeftStorageCapacity(game.getMaterials().getFabric());
            }
            int temp = game.getMaterials().getDyedFabric().getAmount();
            produceMaximumAvailable(game.getMaterials().getDyedFabric(), maximumStorable);
            temp = game.getMaterials().getDyedFabric().getAmount() - temp;
            int use = game.getBuildings().getFabricMerchant().getTotalDyeUse(temp);
            game.getMaterials().getDye().increase(temp - use);
        }
    }

    private void manufactureCloths() {
        int totalCapacity = game.getBuildings().getTailor().getTotalProductionCapacity();
        int clothAtStart = game.getMaterials().getCloth().getAmount();
        int dyedClothAtStart = game.getMaterials().getDyedCloth().getAmount();
        if (game.getMaterials().getDyedCloth().getProductionLevel() != 0) {
            int maxCapacity;
            if (game.getBuildings().getTailor().getTotalProductionCapacity() < game.getBuildings().getTailor().getStorageCapacity(game.getMaterials().getDyedCloth())) {
                maxCapacity = game.getBuildings().getTailor().getTotalProductionCapacity();
            } else {
                maxCapacity = game.getBuildings().getTailor().getStorageCapacity(game.getMaterials().getDyedCloth());
            }
            produceMaximumAvailable(game.getMaterials().getDyedCloth(), maxCapacity);
            dyedClothAtStart = game.getMaterials().getDyedCloth().getAmount() - dyedClothAtStart;
            totalCapacity = totalCapacity - dyedClothAtStart;
        }
        if (game.getMaterials().getCloth().getProductionLevel() != 0) {
            int maxCapacity;
            if (totalCapacity < game.getBuildings().getTailor().getStorageCapacity(game.getMaterials().getDyedFabric())) {
                maxCapacity = totalCapacity;
            } else {
                maxCapacity = game.getBuildings().getTailor().getStorageCapacity(game.getMaterials().getDyedFabric());
            }
            produceMaximumAvailable(game.getMaterials().getDyedCloth(), maxCapacity);
            clothAtStart = game.getMaterials().getCloth().getAmount() - clothAtStart;
        }

        int[] discounts = game.getBuildings().getTailor().getTotalFabricUse(clothAtStart, dyedClothAtStart);
        game.getMaterials().getDyedFabric().increase(dyedClothAtStart - discounts[1]);
        game.getMaterials().getFabric().increase(clothAtStart - discounts[0]);
    }

    private void manufactureArmour() {
        if (game.getMaterials().getArmour().getProductionLevel() != 0) {
            int max;
            if (game.getBuildings().getArmory().getTotalProductionCapacity() < game.getBuildings().getArmory().getLeftStorageCapacity(game.getMaterials().getArmour())) {
                max = game.getBuildings().getArmory().getTotalProductionCapacity();
            } else {
                max = game.getBuildings().getArmory().getLeftStorageCapacity(game.getMaterials().getArmour());
            }
            produceMaximumAvailable(game.getMaterials().getArmour(), max);
        }
    }

    private void manufactureIron() {
        if (game.getMaterials().getIron().getProductionLevel() != 0) {
            int beforeProduction = game.getMaterials().getIron().getAmount();
            int max;
            if (game.getBuildings().getForge().getTotalProductionCapacity() < game.getBuildings().getMetalMerchant().getLeftStorageCapacity(game.getMaterials().getIron())) {
                max = game.getBuildings().getForge().getTotalProductionCapacity();
            } else {
                max = game.getBuildings().getMetalMerchant().getLeftStorageCapacity(game.getMaterials().getIron());
            }
            produceMaximumAvailable(game.getMaterials().getIron(), max);
            int produced = game.getMaterials().getIron().getAmount() - beforeProduction;
            int discount = produced - game.getBuildings().getForge().getTotalIronUsed(produced);
            game.getMaterials().getIronOre().increase(discount);
        }
    }

    private void manufactureAccessory() {
        if (game.getMaterials().getAccessory().getProductionLevel() != 0) {
            int max;
            if (game.getBuildings().getJeweler().getTotalProductionCapacity() < game.getBuildings().getMetalMerchant().getLeftStorageCapacity(game.getMaterials().getAccessory())) {
                max = game.getBuildings().getJeweler().getTotalProductionCapacity();
            } else {
                max = game.getBuildings().getMetalMerchant().getLeftStorageCapacity(game.getMaterials().getAccessory());
            }
            produceMaximumAvailable(game.getMaterials().getAccessory(), max);
        }
    }

    private void manufactureFlour() {
        if (game.getMaterials().getFlour().getProductionLevel() != 0) {
            int max;
            if (game.getBuildings().getMill().getTotalProductionCapacity() < game.getBuildings().getMill().getLeftStorageCapacity(game.getMaterials().getFlour())) {
                max = game.getBuildings().getMill().getTotalProductionCapacity();
            } else {
                max = game.getBuildings().getMill().getLeftStorageCapacity(game.getMaterials().getFlour());
            }
            produceMaximumAvailable(game.getMaterials().getFlour(), max);
        }
    }

    private void manufactureHorse() {
        if (game.getMaterials().getHorse().getProductionLevel() != 0) {
            int max;
            if (game.getBuildings().getStable().getTotalProductionCapacity() < game.getBuildings().getStable().getLeftStorageCapacity(game.getMaterials().getHorse())) {
                max = game.getBuildings().getStable().getTotalProductionCapacity();
            } else {
                max = game.getBuildings().getStable().getLeftStorageCapacity(game.getMaterials().getHorse());
            }
            produceMaximumAvailable(game.getMaterials().getHorse(), max);
        }
    }

    private void manufactureWeapons() {
        int totalProduction = game.getBuildings().getWeaponMaker().getTotalProductionCapacity();
        if (game.getMaterials().getSword().getProductionLevel() != 0) {
            int max;
            if (totalProduction < game.getBuildings().getWeaponMaker().getLeftStorageCapacity(game.getMaterials().getSword())) {
                max = totalProduction;
            } else {
                max = game.getBuildings().getWeaponMaker().getLeftStorageCapacity(game.getMaterials().getSword());
            }
            int beforeProductionAmount = game.getMaterials().getSword().getAmount();
            produceMaximumAvailable(game.getMaterials().getSword(), max);
            totalProduction = game.getMaterials().getSword().getAmount() - beforeProductionAmount;
        }
        if (game.getMaterials().getSpearArrow().getProductionLevel() != 0) {
            int max;
            if (totalProduction < game.getBuildings().getWeaponMaker().getLeftStorageCapacity(game.getMaterials().getSpearArrow())) {
                max = totalProduction;
            } else {
                max = game.getBuildings().getWeaponMaker().getLeftStorageCapacity(game.getMaterials().getSpearArrow());
            }
            produceMaximumAvailable(game.getMaterials().getSpearArrow(), max);
        }
    }

    private void manufactureMeat() {
        if (game.getMaterials().getSaltedMeat().getProductionLevel() != 0) {
            produceMaximumAvailable(game.getMaterials().getMeat(), game.getBuildings().getButchery().getTotalProductionCapacity());
        }
    }

    //this is complicated
    //meat production needs  to be added
    private void manufactureFoodThings() {
        int totalPeopleToFeed = game.getPeople().getAristoi().getPopulationToFeed(game.getFaction().getSyracuse().isBesieged());
        totalPeopleToFeed += game.getPeople().getProletariat().getPopulationToFeed(game.getFaction().getSyracuse().isBesieged());

        int[] minimumAvailableFoods = new int[4];
        if (game.getMaterials().getBread().getProductionLevel() != 0) {
            minimumAvailableFoods[0] += maximumProductionAvailable(game.getMaterials().getBread(), game.getBuildings().getBakery().getTotalProductionCapacity());
        }
        if (game.getMaterials().getSaltedFish().isConsumable()) {
            minimumAvailableFoods[1] += game.getMaterials().getFish().getAmount();
        } else {
            produceMaximumAvailable(game.getMaterials().getSaltedFish(), game.getBuildings().getFishery().getLeftStorageCapacity(game.getMaterials().getSaltedFish()));
            minimumAvailableFoods[2] += game.getMaterials().getMeat().getAmount();
        }
        if (game.getMaterials().getSaltedMeat().isConsumable()) {
            minimumAvailableFoods[2] += game.getMaterials().getMeat().getAmount();
        } else {
            produceMaximumAvailable(game.getMaterials().getSaltedMeat(), game.getBuildings().getButchery().getLeftStorageCapacity(game.getMaterials().getSaltedMeat()));
            minimumAvailableFoods[2] += game.getMaterials().getMeat().getAmount();
        }
        if (game.getMaterials().getCheese().isConsumable()) {
            minimumAvailableFoods[3] += game.getMaterials().getCheese().getAmount();
        }

        int alreadyProducedOnes = minimumAvailableFoods[1] + minimumAvailableFoods[2] + minimumAvailableFoods[3];
        int totalMinimumEdible = alreadyProducedOnes + minimumAvailableFoods[0];
        if (totalMinimumEdible > totalPeopleToFeed) {
            int breadToProduce = 0;
            for (int i = 0; i < 3; i++) {
                int smallest = Integer.MAX_VALUE;
                int indexOf = 3;
                for (int j = 1; j < 4; j++) {
                    if (minimumAvailableFoods[j] < smallest && minimumAvailableFoods[j] >= 0) {
                        smallest = minimumAvailableFoods[j];
                        indexOf = j;
                    }
                }
                if (smallest < totalPeopleToFeed / (4 - i)) {
                    breadToProduce += smallest;
                    for (int j = 1; j < 4; j++) {
                        minimumAvailableFoods[j] -= smallest;
                    }
                    minimumAvailableFoods[indexOf] -= 1;
                    totalPeopleToFeed -= smallest * (4 - i);
                } else {
                    breadToProduce += (totalPeopleToFeed + 1) / (4 - i);
                    break;
                }
            }

            produceMaximumAvailable(game.getMaterials().getBread(), breadToProduce);
        } //this method has a problem actually, if player produces salted meat... I checked again and fuck this method is awesome 
        else {
            produceMaximumAvailable(game.getMaterials().getBread(), game.getBuildings().getBakery().getTotalProductionCapacity());
            int leftPeople = totalPeopleToFeed - totalMinimumEdible;
            if (game.getMaterials().getSaltedFish().isConsumable()) {
                if (game.getMaterials().getSaltedFish().consume(leftPeople)) {
                    game.getMaterials().getFish().increase(leftPeople);
                } else {
                    game.getMaterials().getFish().increase(game.getMaterials().getSaltedFish().getAmount());
                    leftPeople -= game.getMaterials().getSaltedFish().getAmount();
                    game.getMaterials().getSaltedFish().setAmount(0);
                    if (game.getMaterials().getSaltedMeat().isConsumable()) {
                        if (game.getMaterials().getSaltedMeat().consume(leftPeople)) {
                            game.getMaterials().getMeat().increase(leftPeople);
                        } 
                        else {
                            game.getMaterials().getMeat().increase(game.getMaterials().getSaltedMeat().getAmount());
                            game.getMaterials().getSaltedMeat().setAmount(0);
                        }
                    }
                }
            }
        }
        
        
            int flourDiscount = (int) (game.getMaterials().getBread().getCostAmount()[0] * game.getMaterials().getBread().getAmount() - game.getBuildings().getBakery().getTotalFlourUse(game.getMaterials().getBread().getAmount()));
            game.getMaterials().getFlour().increase(flourDiscount);

        } 
    
    public void saltTheFlesh(){
        produceMaximumAvailable(game.getMaterials().getSaltedFish(), Integer.MAX_VALUE);
        produceMaximumAvailable(game.getMaterials().getSaltedMeat(), Integer.MAX_VALUE);
    }
    

    private void manufactureLumber() {
        if (game.getMaterials().getLumber().getProductionLevel() != 0) {
            int maximumStorable;
            if (game.getBuildings().getLumberMerchant().getTotalProductionCapacity() < game.getBuildings().getLumberMerchant().getLeftStorageCapacity(game.getMaterials().getLumber())) {
                maximumStorable = game.getBuildings().getLumberMerchant().getTotalProductionCapacity();
            } else {
                maximumStorable = game.getBuildings().getLumberMerchant().getLeftStorageCapacity(game.getMaterials().getLumber());
            }
            produceMaximumAvailable(game.getMaterials().getLumber(), maximumStorable);
        }
    }

    private void manufactureMarble() {
        if (game.getMaterials().getProcessedMarble().getProductionLevel() != 0) {
            int maximumStorable;
            if (game.getBuildings().getMarbleCutter().getTotalProductionCapacity() < game.getBuildings().getMarbleCutter().getLeftStorageCapacity(game.getMaterials().getProcessedMarble())) {
                maximumStorable = game.getBuildings().getMarbleCutter().getTotalProductionCapacity();
            } else {
                maximumStorable = game.getBuildings().getMarbleCutter().getLeftStorageCapacity(game.getMaterials().getProcessedMarble());
            }
            produceMaximumAvailable(game.getMaterials().getProcessedMarble(), maximumStorable);
        }
    }

    private void manufactureGrapeJuice() {
        produceMaximumAvailable(game.getMaterials().getGrapeJuice(), game.getBuildings().getGrapeJuiceDistillery().getTotalProductionCapacity());
    }

    private void manufacturePig() {
        game.getMaterials().getPig().increase(game.getBuildings().getPigFarm().getFedPigsFromMansions());
        produceMaximumAvailable(game.getMaterials().getPig(), game.getBuildings().getPigFarm().getTotalProductionCapacity());
    }

    private void manufactureOil() {
        produceMaximumAvailable(game.getMaterials().getOliveOil(), game.getBuildings().getOilPresser().getTotalProductionCapacity());
    }
}
