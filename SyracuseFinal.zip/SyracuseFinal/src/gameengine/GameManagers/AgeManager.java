/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameManagers;

import CurrentGameMemory.Game;
import gameengine.GameElementClasses.Building;

/**
 *
 * @author onur
 */
public class AgeManager extends Manager {

    public AgeManager(Game game) {
        super(game);
    }

    public void checkAge() {
        if (game.getAge() == 1 && checkFirstAge()) {
            unlockSecondAge();
        } else if (game.getAge() == 2 && checkSecondAge()) {
            unlockThirdAge();
        }
    }

    private boolean checkFirstAge() {
        return game.getBuildings().getTemple().doesExist();
    }

    private boolean checkSecondAge() {
        return game.getCityStatus().getExpeditionDeadlineLeft() < 1 && !game.getFaction().getSyracuse().isBesieged();
    }

    //unlocker methods needs to be written
    private void unlockSecondAge() {
        for (Building allBuilding : game.getBuildings().getAllBuildings()) {
            if (allBuilding.isRequirementDependOnlyOnAge()) {
                if (allBuilding.getRequirementAge() == 2) {
                    allBuilding.setUnlocked(true);
                }
            }
        }
        game.setAge(2);
    }

    private void unlockThirdAge() {
        for (Building allBuilding : game.getBuildings().getAllBuildings()) {
            if (allBuilding.isRequirementDependOnlyOnAge()) {
                if (allBuilding.getRequirementAge() == 3) {
                    allBuilding.setUnlocked(true);
                }
            }
        }
        game.setAge(3);
    }
}
