/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameManagers;

import CurrentGameMemory.Game;
import gameengine.GameElementClasses.County;

/**
 *
 * @author onur
 */
public class PopulationManager extends Manager {

    public PopulationManager(Game game) {
        super(game);
    }
    
    
    public void returnToCity(County county, int pop){
        if(county.getOwner()==game.getFaction()&&county.getWorkerPeople()>=pop){
            county.decreaseWorkerPeople(pop);
            if(county.getProducedMaterial().isGathererSlave()){
                game.getPeople().getSlaves().adjustCityPopulation(pop);
                game.getPeople().getSlaves().adjustUnemployedPopulation(pop);
                game.getPeople().getSlaves().adjustCountyPopulation(-pop);
            }
            else{
                game.getPeople().getProletariat().adjustCityPopulation(pop);
                game.getPeople().getProletariat().adjustUnemployedPopulation(pop);
                game.getPeople().getProletariat().adjustCountyPopulation(-pop);
            }
        }
    }
    
    public void sendToProvince(County county, int pop){
        if(county.getOwner()==game.getFaction()){
            if(county.getProducedMaterial().isGathererSlave()&&game.getPeople().getSlaves().getUnemployed()>=pop){
                game.getPeople().getSlaves().adjustCityPopulation(-pop);
                game.getPeople().getSlaves().adjustUnemployedPopulation(-pop);
                game.getPeople().getSlaves().adjustCountyPopulation(pop);
                county.adjustWorkerPeople(pop);
            }
            else if(!county.getProducedMaterial().isGathererSlave()&&game.getPeople().getProletariat().getUnemployed()>=pop){
                game.getPeople().getProletariat().adjustCityPopulation(-pop);
                game.getPeople().getProletariat().adjustUnemployedPopulation(-pop);
                game.getPeople().getProletariat().adjustCountyPopulation(pop);
                county.adjustWorkerPeople(pop);
            }
        }
    }

    //bu defterde vardı ya
    public void calculateHappiness() {
        int commonHappiness = game.getCityStatus().getHappinessFromWar();
        commonHappiness += game.getBuildings().getMonument().getHappinessForCivic(game.getPlayerCivics().getGovCiv());
        commonHappiness += game.getBuildings().getCourtHouse().getHappiness(game.getPlayerCivics().getGovCiv());
        commonHappiness += game.getBuildings().getTemple().getTotalHappıness();

        game.getPeople().getAristoi().adjustHappiness(commonHappiness);
        game.getPeople().getProletariat().adjustHappiness(commonHappiness);

        int proHappiness = 0;
        int ariHappiness = 0;

        proHappiness += game.getBuildings().getPublicBath().getProletariatHappiness() + game.getBuildings().getHouse().getHappinessFromHousing() + game.getBuildings().getShrine().getHappinessFromShrines();
        proHappiness += game.getBuildings().getTheatre().getProletariatHappiness();

        ariHappiness += game.getBuildings().getPublicBath().getAristoiHappiness() + game.getBuildings().getMansion().getHappinessFromHousing();
        ariHappiness += game.getBuildings().getJeweler().getTotalHappiness();
        ariHappiness -= game.getBuildings().getForge().getUnappinessProduced();
        ariHappiness += game.getBuildings().getTheatre().getAristoiHappiness();

        game.getPeople().getAristoi().adjustHappiness(ariHappiness);
        game.getPeople().getProletariat().adjustHappiness(proHappiness);

        int proRealHappiness = game.getPeople().getProletariat().getHappiness() + 40 - game.getPeople().getProletariat().getTotalPopulation() / 2000;
        int ariRealHappiness = game.getPeople().getAristoi().getHappiness() + 40 - game.getPeople().getAristoi().getTotalPopulation() / 2000;

        game.getPeople().getAristoi().setHappiness(ariRealHappiness);
        game.getPeople().getProletariat().setHappiness(proRealHappiness);
    }

    public void calculateNewPopulation() {
        disposeSlaves();
        int proHappiness = game.getPeople().getProletariat().getHappiness();
        double proPopMultiplier = (proHappiness - 30) / 1000.0 + 1;
        int ariHappiness = game.getPeople().getAristoi().getHappiness();
        double ariPopMultiplier = (ariHappiness - 30) / 1000.0 + 1;

        //population can't decrease
        if (ariPopMultiplier < 1) {
            ariPopMultiplier = 1;
        }
        if (proPopMultiplier < 1) {
            proPopMultiplier = 1;
        }

        increaseCountyPop(proPopMultiplier);
        int cityIncreaseProletariat = (int) (((proPopMultiplier - 1) * game.getPeople().getProletariat().getCountInCity()));
        int cityIncreaseAristoi = (int) (((ariPopMultiplier - 1) * game.getPeople().getAristoi().getCountInCity()));

        game.getPeople().getProletariat().increasePopInCity(cityIncreaseProletariat);
        game.getPeople().getAristoi().increasePopInCity(cityIncreaseAristoi);

        if(game.getPeople().getAristoi().getCountInCity()>game.getBuildings().getMansion().getTotalHousing())
            game.getPeople().getAristoi().increasePopInCity(-game.getPeople().getAristoi().getCountInCity()+game.getBuildings().getMansion().getTotalHousing());
        if(game.getPeople().getProletariat().getCountInCity()>game.getBuildings().getHouse().getTotalHousing())
            game.getPeople().getProletariat().increasePopInCity(-game.getPeople().getProletariat().getCountInCity()+game.getBuildings().getHouse().getTotalHousing());
        calculateAcademy();
    }

    //each year %5 of the slaves die due to stuff-hard working
    public void disposeSlaves() {
        if (game.getAge() % 12 == 0) {
            for (int i = 0; i < game.getFaction().getCounties().size(); i++) {
                if (game.getFaction().getCounties().get(i).getProducedMaterial().isGathererSlave()) {
                    game.getPeople().getSlaves().adjustCountyPopulation(-game.getFaction().getCounties().get(i).decreaseWorkerPercent(5));
                }
                int deceaseAmount;
                deceaseAmount = game.getPeople().getSlaves().getCountInCity() / 20;
                game.getPeople().getSlaves().adjustUnemployedPopulation(-deceaseAmount);
                game.getPeople().getSlaves().adjustCityPopulation(-deceaseAmount);
            }
        }
    }

    public void increaseCountyPop(double proportion) {
        for (int i = 0; i < game.getFaction().getCounties().size(); i++) {
            if (!game.getFaction().getCounties().get(i).getProducedMaterial().isGathererSlave()) {
                int increaseAmount = (int) (game.getFaction().getCounties().get(i).getWorkerPeople() * (proportion - 1));
                game.getFaction().getCounties().get(i).adjustWorkerPeople(increaseAmount);
                game.getPeople().getProletariat().adjustCountyPopulation(increaseAmount);
                if (game.getFaction().getCounties().get(i).getWorkerPeople() > 5000) {
                    game.getPeople().getProletariat().increasePopInCity(game.getFaction().getCounties().get(i).getWorkerPeople() - 5000);
                    game.getPeople().getProletariat().adjustCountyPopulation(-game.getFaction().getCounties().get(i).getWorkerPeople() - 5000);
                    game.getFaction().getCounties().get(i).setWorkerPeople(5000);
                }
            }
        }
    }

    //need to find a punishment for the -unemployed people in the city
    public void handleMisPopulation() {
        int shouldBePopPro = game.getPeople().getProletariat().getCountInCounties();
        int shouldbePopSlave = game.getPeople().getSlaves().getCountInCounties();

        int numberOfProCounties=0;
        int numberOfSlaveCounties=0;
        int currentPro = 0, currentSlave = 0;
        for (int i = 0; i < game.getFaction().getCounties().size(); i++) {
            if (game.getFaction().getCounties().get(i).getProducedMaterial().isGathererSlave()) {
                currentSlave += game.getFaction().getCounties().get(i).getWorkerPeople();
                numberOfSlaveCounties++;
            } else {
                currentPro += game.getFaction().getCounties().get(i).getWorkerPeople();
                numberOfProCounties++;
            }
        }

        int difPro=shouldBePopPro-currentPro;
        if(difPro<0){
            while(difPro!=0){
                int amountToDecrease=difPro/numberOfProCounties;
                for (int i = 0; i < game.getFaction().getCounties().size(); i++)
                    if (!game.getFaction().getCounties().get(i).getProducedMaterial().isGathererSlave())
                        if(game.getFaction().getCounties().get(i).getWorkerPeople()>amountToDecrease){
                            game.getFaction().getCounties().get(i).decreaseWorkerPeople(amountToDecrease);
                            difPro-=amountToDecrease;
                        }
                        else{
                            difPro-=game.getFaction().getCounties().get(i).getWorkerPeople();
                            game.getFaction().getCounties().get(i).setWorkerPeople(0);
                        }
                numberOfProCounties--;
            }
        }
        
        int difSlave=shouldbePopSlave-currentSlave;
        if(difSlave<0){
            while(difSlave!=0){
                int amountToDecrease=difSlave/numberOfSlaveCounties;
                for (int i = 0; i < game.getFaction().getCounties().size(); i++)
                    if (game.getFaction().getCounties().get(i).getProducedMaterial().isGathererSlave())
                        if(game.getFaction().getCounties().get(i).getWorkerPeople()>amountToDecrease){
                            game.getFaction().getCounties().get(i).decreaseWorkerPeople(amountToDecrease);
                            difSlave-=amountToDecrease;
                        }
                        else{
                            difSlave-=game.getFaction().getCounties().get(i).getWorkerPeople();
                            game.getFaction().getCounties().get(i).setWorkerPeople(0);
                        }
                numberOfSlaveCounties--;
            }
        }
    }

    private void calculateAcademy() {
        if(game.getPeople().getProletariat().getUnemployed()<game.getBuildings().getAcademy().getConvertedPeople()){
            game.getPeople().getAristoi().increasePopInCity(game.getPeople().getProletariat().getUnemployed());
            game.getPeople().getProletariat().increasePopInCity(-game.getPeople().getProletariat().getUnemployed());
        }
        else{
            game.getPeople().getAristoi().increasePopInCity(game.getBuildings().getAcademy().getConvertedPeople());
            game.getPeople().getProletariat().increasePopInCity(-game.getBuildings().getAcademy().getConvertedPeople());
        }
    }
}
