/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameManagers;

import CurrentGameMemory.Game;
import gameengine.GameElementClasses.AIFaction;
import gameengine.GameElementClasses.Faction;
import gameengine.GameElementClasses.Material;
import gameengine.GameElementClasses.PeloponnesianFaction;
import gameengine.GameElementClasses.SicilyFaction;
import gameengine.GameElementClasses.ThirdAgeFaction;
import gameengine.GameElementClasses.TradeOffer;
import gameengine.GameElementClasses.TradeShipment;
import java.util.ArrayList;

/**
 *
 * @author onur
 */
public class ForeignManager extends Manager {

    public ForeignManager(Game game) {
        super(game);
    }

    public void createMissions() {
        if (Math.random() > 0.7) {
            if (game.getAge() == 1) {
                createFirstAgeMission();
            } else if (game.getAge() == 2) {
                createSecondAgeMission();
            } else {
                createThirdAgeMission();
            }
        }
    }

    public void balanceRelations() {
        if (game.getAge() == 1) {
            game.getAiFactions().getCorinth().updateRelation(game.getPlayerCivics().getCivics(), null);
        }

        if (game.getAge() == 2) {
            for (PeloponnesianFaction peloponnesianFaction : game.getAiFactions().getPeloponnesianFactions()) {
                peloponnesianFaction.updateRelation(game.getPlayerCivics().getCivics(), null);
            }
            if (game.getAiFactions().getAthens().getCurrentAttitude() + game.getAiFactions().getSparta().getCurrentAttitude() > 110) {
                int overRelation = (game.getAiFactions().getAthens().getCurrentAttitude() + game.getAiFactions().getSparta().getCurrentAttitude() - 110) / 2;
                if (Math.random() < 0.5) {
                    game.getAiFactions().getAthens().increaseRelation(-overRelation);
                } else {
                    game.getAiFactions().getAthens().increaseRelation(-overRelation);
                }
            }
        }
    }

    private void createSecondAgeMission() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void createFirstAgeMission() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void moveShipments() {
        for (int i = 0; i < game.getActiveThings().getShipments().size(); i++) {
            game.getActiveThings().getShipments().get(i).moveShipment(game.getFaction().getSyracuse().isBlockaded());
            if (game.getActiveThings().getShipments().get(i).isReturned()) {
                game.getActiveThings().getShipments().remove(i);
                game.getPeople().getSlaves().adjustCityPopulation(game.getMaterials().getSlave().getAmount());
                game.getPeople().getSlaves().adjustUnemployedPopulation(game.getMaterials().getSlave().getAmount());
                game.getMaterials().getSlave().setAmount(0);
                i--;
            }
        }
    }

    public void createTradeOffers() {
        if (game.getAge() == 1) {
            addFirstAgeOffers();
        } else if (game.getAge() == 2) {
            addSecondAgeOffers();
            if (game.getBuildings().getLightHouse().doesExist()) {
                addSecondAgeOffers();
            }
        } else {
            addThirdAgeOffers();
            if (game.getBuildings().getLightHouse().doesExist()) {
                addThirdAgeOffers();
            }
        }
    }

    private void addThirdAgeOffers() {
        addSicilyFactionTradeOffer();
        addFreeCitiesTradeOffer();
        addHellenisticTradeOffer();
    }

    private void addSicilyFactionTradeOffer() {
        SicilyFaction[] factions = game.getAiFactions().getSicilyFactionsWithoutRebelFaction();
        SicilyFaction randomFaction = factions[(int) (Math.random() * factions.length)];
        if (!isAtWarWithEachOther(randomFaction, game.getFaction())) {
            ArrayList<Material> exports = getExports(randomFaction);
            ArrayList<Material> imports = getImports(randomFaction);

            Material exportMaterial = exports.get((int) (Math.random() * exports.size()));
            Material importMaterial = imports.get((int) (Math.random() * imports.size()));
            ThirdAgeFaction[] possibleNeutrals = new ThirdAgeFaction[]{game.getAiFactions().getRome(), game.getAiFactions().getCarthage(), game.getAiFactions().getFreeCities()};
            boolean neutralsSelling = areNeutralsSelling(importMaterial, randomFaction, possibleNeutrals);

            int amountToExport, amountToImport;
            boolean fullExport, fullImport;

            if (Math.random() * 2 > 1) {
                amountToExport = exportMaterial.getRequiredAmountToFillShip();
                fullExport = true;
            } else {
                amountToExport = exportMaterial.getRequiredAmountToFillShip() / 2;
                fullExport = false;
            }

            if (Math.random() * 2 > 1) {
                amountToImport = importMaterial.getRequiredAmountToFillShip();
                fullImport = true;
            } else {
                amountToImport = importMaterial.getRequiredAmountToFillShip() / 2;
                fullImport = false;
            }

            int baseExportCost = amountToExport * exportMaterial.getBaseTradeCost();
            int baseImportCost = amountToImport * importMaterial.getBaseTradeCost();

            if (neutralsSelling) {
                baseImportCost = baseImportCost * 9 / 10;
            }

            baseExportCost = getRandomizedAmount(baseExportCost);
            baseImportCost = getRandomizedAmount(baseImportCost);

            double modifier = getAttitudeTradeMultiplier(randomFaction);
            baseExportCost = (int) (baseExportCost / modifier);
            baseImportCost = (int) (baseImportCost / modifier);

            TradeOffer export = new TradeOffer(randomFaction, exportMaterial, amountToExport, true, baseExportCost, fullExport, getRandomDurationTime());
            TradeOffer import1 = new TradeOffer(randomFaction, importMaterial, amountToImport, false, baseImportCost, fullImport, getRandomDurationTime());

            game.getActiveThings().getTradeOffers().add(export);
            game.getActiveThings().getTradeOffers().add(import1);
        }
    }

    private void addFreeCitiesTradeOffer() {
        Material materialToExport, materialToImport;
        materialToExport = game.getMaterials().getAlltradeMaterials()[(int) (game.getMaterials().getAlltradeMaterials().length * Math.random())];
        materialToImport = game.getMaterials().getAlltradeMaterials()[(int) (game.getMaterials().getAlltradeMaterials().length * Math.random())];

        int amountExport, amountImport;
        boolean fullExport, fullImport;

        if (Math.random() * 2 > 1) {
            amountExport = materialToExport.getRequiredAmountToFillShip();
            fullExport = true;
        } else {
            amountExport = materialToExport.getRequiredAmountToFillShip() / 2;
            fullExport = false;
        }

        if (Math.random() * 2 > 1) {
            amountImport = materialToImport.getRequiredAmountToFillShip();
            fullImport = true;
        } else {
            amountImport = materialToImport.getRequiredAmountToFillShip() / 2;
            fullImport = false;
        }

        int baseExportCost = amountExport * materialToExport.getBaseTradeCost();
        int baseImportCost = amountImport * materialToImport.getBaseTradeCost();

        baseExportCost = getRandomizedAmount(baseExportCost);
        baseImportCost = getRandomizedAmount(baseImportCost);

        TradeOffer exportOffer, importOffer;
        exportOffer = new TradeOffer(game.getAiFactions().getFreeCities(), materialToExport, amountExport, true, baseExportCost, fullExport, getRandomDurationTime());
        importOffer = new TradeOffer(game.getAiFactions().getFreeCities(), materialToImport, amountImport, false, baseImportCost, fullImport, getRandomDurationTime());

        game.getActiveThings().getTradeOffers().add(importOffer);
        game.getActiveThings().getTradeOffers().add(exportOffer);
    }

    private void addHellenisticTradeOffer() {
        ThirdAgeFaction[] factions = game.getAiFactions().getThirdAgeFactionsWithoutFreeCities();
        ThirdAgeFaction randomFaction = factions[(int) (Math.random() * factions.length)];
        if (!isAtWarWithEachOther(randomFaction, game.getFaction())) {
            ArrayList<Material> exports = getExports(randomFaction);
            ArrayList<Material> imports = getImports(randomFaction);

            Material exportMaterial = exports.get((int) (Math.random() * exports.size()));
            Material importMaterial = imports.get((int) (Math.random() * imports.size()));
            boolean neutralsSelling = areNeutralsSelling(importMaterial, randomFaction, game.getAiFactions().getThirdAgeFactions());

            int amountToExport, amountToImport;
            boolean fullExport, fullImport;

            if (Math.random() * 2 > 1) {
                amountToExport = exportMaterial.getRequiredAmountToFillShip();
                fullExport = true;
            } else {
                amountToExport = exportMaterial.getRequiredAmountToFillShip() / 2;
                fullExport = false;
            }

            if (Math.random() * 2 > 1) {
                amountToImport = importMaterial.getRequiredAmountToFillShip();
                fullImport = true;
            } else {
                amountToImport = importMaterial.getRequiredAmountToFillShip() / 2;
                fullImport = false;
            }

            int baseExportCost = amountToExport * exportMaterial.getBaseTradeCost();
            int baseImportCost = amountToImport * importMaterial.getBaseTradeCost();

            if (neutralsSelling) {
                baseImportCost = baseImportCost * 9 / 10;
            }

            baseExportCost = getRandomizedAmount(baseExportCost);
            baseImportCost = getRandomizedAmount(baseImportCost);

            double modifier = getAttitudeTradeMultiplier(randomFaction);
            baseExportCost = (int) (baseExportCost / modifier);
            baseImportCost = (int) (baseImportCost / modifier);

            TradeOffer export = new TradeOffer(randomFaction, exportMaterial, amountToExport, true, baseExportCost, fullExport, getRandomDurationTime());
            TradeOffer import1 = new TradeOffer(randomFaction, importMaterial, amountToImport, false, baseImportCost, fullImport, getRandomDurationTime());

            game.getActiveThings().getTradeOffers().add(export);
            game.getActiveThings().getTradeOffers().add(import1);
        }
    }

    private boolean areNeutralsSelling(Material material, ThirdAgeFaction faction, ThirdAgeFaction[] others) {
        for (int i = 0; i < others.length; i++) {
            if (others[i] != faction && !isAtWarWithEachOther(faction, others[i])) {
                for (int j = 0; j < others[i].getRegions().size(); j++) {
                    if (others[i].getRegions().get(j).getTradeResource() == material) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private ArrayList<Material> getExports(ThirdAgeFaction faction) {
        ArrayList<Material> array = new ArrayList();
        for (int i = 0; i < faction.getRegions().size(); i++) {
            boolean match = false;
            for (int j = 0; j < array.size(); j++) {
                if (array.get(j) == faction.getRegions().get(i).getTradeResource()) {
                    match = true;
                    break;
                }
            }
            if (!match) {
                array.add(faction.getRegions().get(i).getTradeResource());
            }
        }
        return array;
    }

    private boolean isAtWarWithEachOther(Faction faction, Faction otherFaction) {
        for (int i = 0; i < faction.getAtWarList().size(); i++) {
            if (faction.getAtWarList().get(i) == otherFaction) {
                return true;
            }
        }
        return false;
    }

    private ArrayList<Material> getImports(ThirdAgeFaction faction) {
        ArrayList<Material> exportArray = getExports(faction);
        return findExclude(game.getMaterials().getAlltradeMaterials(), exportArray);
    }

    private ArrayList<Material> findExclude(Material[] allTradables, ArrayList<Material> exports) {
        ArrayList<Material> imports = new ArrayList();
        for (int i = 0; i < allTradables.length; i++) {
            boolean found = false;
            for (int j = 0; j < exports.size(); j++) {
                if (exports.get(j) == allTradables[i]) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                imports.add(allTradables[i]);
            }
        }
        return imports;
    }

    private void addSecondAgeOffers() {
        Material materialExportSparta = getRandomMaterial(game.getMaterials().getAllFoodTradeMaterials()),
                materialExportAthens = getRandomMaterial(game.getMaterials().getAllNonFoodTradeMaterials()),
                materialImportAthens = getRandomMaterial(game.getMaterials().getAllFoodTradeMaterials()),
                materialImportSparta = getRandomMaterial(game.getMaterials().getAllNonFoodTradeMaterials());

        int spartaExportAmount, spartaImportAmount, athensExportAmount, athensImportAmount;
        boolean spartaFullExport, athensFullExport, spartaFullImport, athensFullImport;

        if (Math.random() * 2 > 1) {
            spartaExportAmount = materialExportSparta.getRequiredAmountToFillShip();
            spartaFullExport = true;
        } else {
            spartaExportAmount = materialExportSparta.getRequiredAmountToFillShip() / 2;
            spartaFullExport = false;
        }

        if (Math.random() * 2 > 1) {
            spartaImportAmount = materialImportSparta.getRequiredAmountToFillShip();
            spartaFullImport = true;
        } else {
            spartaImportAmount = materialImportSparta.getRequiredAmountToFillShip() / 2;
            spartaFullImport = false;
        }

        if (Math.random() * 2 > 1) {
            athensExportAmount = materialExportAthens.getRequiredAmountToFillShip();
            athensFullExport = true;
        } else {
            athensExportAmount = materialExportAthens.getRequiredAmountToFillShip() / 2;
            athensFullExport = false;
        }

        if (Math.random() * 2 > 1) {
            athensImportAmount = materialImportAthens.getRequiredAmountToFillShip();
            athensFullImport = true;
        } else {
            athensImportAmount = materialImportAthens.getRequiredAmountToFillShip() / 2;
            athensFullImport = false;
        }

        int spartaExportCost = spartaExportAmount * materialExportSparta.getBaseTradeCost();
        int spartaImportCost = spartaImportAmount * materialImportSparta.getBaseTradeCost();

        int athensImportCost = athensImportAmount * materialImportAthens.getBaseTradeCost();
        int athensExportCost = athensExportAmount * materialExportAthens.getBaseTradeCost();

        double attitudeMultiplierAthens = getAttitudeTradeMultiplier(game.getAiFactions().getAthens());
        double attitudeMultiplierSparta = getAttitudeTradeMultiplier(game.getAiFactions().getSparta());

        spartaExportCost = (int) (spartaExportCost / attitudeMultiplierSparta);
        spartaImportCost = (int) (spartaImportCost * attitudeMultiplierSparta);
        athensImportCost = (int) (athensImportCost * attitudeMultiplierAthens);
        athensExportCost = (int) (athensExportCost / attitudeMultiplierAthens);

        spartaExportCost = getRandomizedAmount(spartaExportCost);
        spartaImportCost = getRandomizedAmount(spartaImportCost);
        athensImportCost = getRandomizedAmount(athensImportCost);
        athensExportCost = getRandomizedAmount(athensExportCost);
        
        if(materialExportAthens==game.getMaterials().getSlave())
            athensExportCost=athensExportCost*(int)(100-game.getBuildings().getSlaveTrader().getSlaveTradingModifier())/100;
        if(materialExportSparta==game.getMaterials().getSlave())
            spartaExportCost=spartaExportCost*(int)(100-game.getBuildings().getSlaveTrader().getSlaveTradingModifier())/100;

        TradeOffer exportSparta, importSparta, exportAthens, importAthens;
        exportSparta = new TradeOffer(game.getAiFactions().getSparta(), materialExportSparta, spartaExportAmount, true, spartaExportCost, spartaFullExport, getRandomDurationTime());

        importSparta = new TradeOffer(game.getAiFactions().getSparta(), materialImportSparta, spartaImportAmount, false, spartaImportCost, spartaFullImport, getRandomDurationTime());

        exportAthens = new TradeOffer(game.getAiFactions().getAthens(), materialExportAthens, athensExportAmount, true, athensExportCost, athensFullExport, getRandomDurationTime());

        importAthens = new TradeOffer(game.getAiFactions().getAthens(), materialImportSparta, athensImportAmount, false, athensImportCost, athensFullImport, getRandomDurationTime());

        game.getActiveThings().getTradeOffers().add(exportSparta);
        game.getActiveThings().getTradeOffers().add(importSparta);
        game.getActiveThings().getTradeOffers().add(exportAthens);
        game.getActiveThings().getTradeOffers().add(importAthens);
    }

    private void addFirstAgeOffers() {
        Material materialToExport, materialToImport;
        materialToExport = game.getMaterials().getAlltradeMaterials()[(int) (game.getMaterials().getAlltradeMaterials().length * Math.random())];
        materialToImport = game.getMaterials().getAlltradeMaterials()[(int) (game.getMaterials().getAlltradeMaterials().length * Math.random())];

        int amountExport, amountImport;
        boolean fullExport, fullImport;

        if (Math.random() * 2 > 1) {
            amountExport = materialToExport.getRequiredAmountToFillShip();
            fullExport = true;
        } else {
            amountExport = materialToExport.getRequiredAmountToFillShip() / 2;
            fullExport = false;
        }

        if (Math.random() * 2 > 1) {
            amountImport = materialToImport.getRequiredAmountToFillShip();
            fullImport = true;
        } else {
            amountImport = materialToImport.getRequiredAmountToFillShip() / 2;
            fullImport = false;
        }

        int baseExportCost = amountExport * materialToExport.getBaseTradeCost();
        int baseImportCost = amountImport * materialToImport.getBaseTradeCost();

        double attitudeMultiplier = getAttitudeTradeMultiplier(game.getAiFactions().getCorinth());
        baseExportCost = (int) (baseExportCost / attitudeMultiplier);
        baseImportCost = (int) (baseImportCost / attitudeMultiplier);

        baseExportCost = getRandomizedAmount(baseExportCost);
        baseImportCost = getRandomizedAmount(baseImportCost);

        if(materialToExport==game.getMaterials().getSlave())
            baseExportCost=baseExportCost*(int)(100-game.getBuildings().getSlaveTrader().getSlaveTradingModifier())/100;
        
        TradeOffer exportOffer, importOffer;
        exportOffer = new TradeOffer(game.getAiFactions().getCorinth(), materialToExport, amountExport, true, baseExportCost, fullExport, getRandomDurationTime());
        importOffer = new TradeOffer(game.getAiFactions().getCorinth(), materialToImport, amountImport, false, baseImportCost, fullImport, getRandomDurationTime());

        game.getActiveThings().getTradeOffers().add(importOffer);
        game.getActiveThings().getTradeOffers().add(exportOffer);
    }

    private double getAttitudeTradeMultiplier(AIFaction faction) {
        return 1 + (faction.getCurrentAttitude() - 50) / 500.0;
    }

    private int getRandomizedAmount(int amount) {
        return (int) (amount * (90 + Math.random() * 20) / 100);
    }

    private Material getRandomMaterial(Material[] materials) {
        return materials[(int) (Math.random() * materials.length)];
    }

    private int getRandomDurationTime() {
        return (int) (Math.random() * 6 + 3);
    }

    public void createShipment(TradeOffer[] offers) {
        if (offers.length > 0 && areOffersFromSameFaction(offers) && canFitInAShip(offers) && playerHasEnoughResources(offers) && !game.getFaction().getSyracuse().isBlockaded()) {
            if (game.getBuildings().getDock().getTotalShipCount() > game.getActiveThings().getShipments().size()) {
                boolean longDist
                        = offers[0].getSender() == game.getAiFactions().getPtolemies()
                        || offers[0].getSender() == game.getAiFactions().getSeleucids()
                        || offers[0].getSender() == game.getAiFactions().getAntigonids();

                int slavesToConvert = 0;
                for (int i = 0; i < offers.length; i++) {
                    if (offers[i].getResource() == game.getMaterials().getSlave()) {
                        if (offers[i].isFactionExporting()) {
                            slavesToConvert -= offers[i].getAmount();
                        } else {
                            slavesToConvert += offers[i].getAmount();
                        }
                    }
                }
                
                if(slavesToConvert>0){
                    game.getPeople().getSlaves().adjustCityPopulation(-slavesToConvert);
                    game.getPeople().getSlaves().adjustUnemployedPopulation(-slavesToConvert);
                    game.getMaterials().getSlave().setAmount(slavesToConvert);
                }
                TradeShipment shipment = new TradeShipment(offers, longDist);
                //amount that each trade offer increases relation
                offers[0].getSender().increaseRelation(10);
                int moneyChange = shipment.getTotalMoneyChange();
                if (game.getPlayerCivics().getGovCiv().getName().equals("Democracy") && moneyChange < 0) {
                    moneyChange = moneyChange * 9 / 10;
                } else if (game.getPlayerCivics().getGovCiv().getName().equals("Aristocracy") && moneyChange > 0) {
                    moneyChange = moneyChange * 10 / 9;
                }

                game.addMoney(moneyChange);
                game.getActiveThings().getShipments().add(shipment);
            }

        }
    }

    private boolean playerHasEnoughResources(TradeOffer[] offers) {
        int totalMoneyChange = 0;
        for (int i = 0; i < offers.length; i++) {
            if (offers[i].isFactionExporting()) {
                totalMoneyChange -= offers[i].getCost();
            } else {
                totalMoneyChange += offers[i].getCost();
            }
        }
        if (game.getMoney() >= -totalMoneyChange) {
            return false;
        }

        ArrayList<Material> list = new ArrayList();
        ArrayList<Integer> amountList = new ArrayList();
        for (int i = 0; i < offers.length; i++) {
            if (!offers[i].isFactionExporting()) {
                int index = -1;
                for (int j = 0; j < list.size(); j++) {
                    if (list.get(j) == offers[i].getResource()) {
                        index = j;
                    }
                }
                if (index != -1) {
                    amountList.set(index, amountList.get(index) + offers[i].getAmount());
                } else {
                    list.add(offers[i].getResource());
                    amountList.add(offers[i].getAmount());
                }
            }
        }
        for (int i = 0; i < list.size(); i++) {
            if ((list.get(i).getAmount() < amountList.get(i) && list.get(i) != game.getMaterials().getSlave()) || (list.get(i) == game.getMaterials().getSlave() && game.getPeople().getSlaves().getUnemployed() < amountList.get(i))) {
                return false;
            }
        }
        return true;
    }

    private boolean areOffersFromSameFaction(TradeOffer[] offers) {
        AIFaction fac = offers[0].getSender();
        for (int i = 1; i < offers.length; i++) {
            if (fac != offers[i].getSender()) {
                return false;
            }
        }
        return true;
    }

    private boolean canFitInAShip(TradeOffer[] offers) {
        int t = 0;
        for (int i = 0; i < offers.length; i++) {
            if (offers[i].isFullShipment()) {
                t += 2;
            } else {
                t += 1;
            }
        }
        if (game.getPlayerCivics().getEcoCiv().getName().equals("Trade Economy") && t < 4) {
            return true;
        } else if (t < 3) {
            return true;
        } else {
            return false;
        }
    }

    private void createThirdAgeMission() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
