/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameManagers;

import CurrentGameMemory.Game;
import gameengine.GameElementClasses.Civic;
import gameengine.GameElementClasses.EconomicCivic;
import gameengine.GameElementClasses.GovernmentCivic;
import gameengine.GameElementClasses.MilitaryCivic;

/**
 *
 * @author onur
 */
public class CityManager extends Manager{

    public CityManager(Game game) {
        super(game);
    }

    public void manageCity(){
        game.getCityStatus().passTurn();
    }
    
    public void updateCivics(String[] civics){
        game.getPlayerCivics().setGovCiv(new GovernmentCivic(civics[0]));
        game.getPlayerCivics().setEcoCiv(new EconomicCivic(civics[1]));
        game.getPlayerCivics().setMilCiv(new MilitaryCivic(civics[2]));
        game.getCityStatus().setAnarchyLeft(game.getBuildings().getPalace().getMaximumAnarchy());
    }
}
