/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameManagers;

import CurrentGameMemory.Game;

/**
 *
 * @author onur
 */
public class TerminationManager extends Manager {
    
    public TerminationManager(Game game) {
        super(game);
    }
    
    public boolean isVictory() {
        return game.getAge()==3&&checkWonders()||checkDiplomaticVictory()||
                checkSicilyConquered();
    }
    
    public boolean isDefeat() {
        return checkFirstAgeDeadline()||checkCityLost()||checkRebellion();
    }
    
    private boolean checkWonders() {
        return game.getBuildings().getGreatLighthouse().doesExist()
                || game.getBuildings().getColossus().doesExist()
                || game.getBuildings().getParthenon().doesExist()
                || game.getBuildings().getStatueOfZeus().doesExist();
    }
    
    private boolean checkDiplomaticVictory() {
        if (game.getAiFactions().getCarthage().getCapital().getOwner() == game.getAiFactions().getRome()) {
            if (game.getAiFactions().isPreviousTurnCarthageOwnerIsCarthage()) {
                for (int i = 0; i < game.getFaction().getAtWarList().size(); i++) {
                    if (game.getFaction().getAtWarList().get(i) == game.getAiFactions().getCarthage()
                            && game.getAiFactions().getRome().getCurrentAttitude() > 60) {
                        return true;
                    }
                }
            }
        }
        if (game.getAiFactions().getRome().getCapital().getOwner() == game.getAiFactions().getCarthage()) {
            if (game.getAiFactions().isPreviousTurnRomeOwnerIsRome()) {
                for (int i = 0; i < game.getFaction().getAtWarList().size(); i++) {
                    if (game.getFaction().getAtWarList().get(i) == game.getAiFactions().getRome()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    //will be added after places class is created
    private boolean checkSicilyConquered()
    {
        return
                game.getPlaces().getMessinaProvince().getOwner()==game.getFaction()&&
                game.getPlaces().getLilybaeumProvince().getOwner()==game.getFaction();
    }

    private boolean checkCityLost() {
        return game.getFaction() != game.getFaction().getSyracuse().getOwner();
    }
    
    private boolean checkRebellion() {
        return (game.getPeople().getAristoi().getHappiness() < 15
                && !game.getPlayerCivics().getGovCiv().getName().equals("Aristocracy"))
                || (game.getPeople().getProletariat().getHappiness() < 15
                && !game.getPlayerCivics().getGovCiv().getName().equals("Democracy"));
    }
    
    private boolean checkFirstAgeDeadline() {
        game.getCityStatus().setExpeditionDeadlineLeft(game.getCityStatus().getFirstAgeDeadlineLeft() - 1);
        return game.getAge() == 1 && game.getCityStatus().getFirstAgeDeadlineLeft() == 0;
    }
}
