/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameengine.GameManagers;

import CurrentGameMemory.Game;
import CurrentGameMemory.Player;

/**
 *
 * @author onur
 */
public class GameManager extends Manager{

    private AgeManager ageManager;
    private  BuildingManager buildingManager;
    private  CityManager cityManager;
    private  ForeignManager foreignManager;
    private  MaterialAndHappinessManager materialAndHappinessManager;
    private  PopulationManager populationManager;
    private  RecruitmentManager recruitmentManager;
    private TerminationManager terminationManager;
    public GameManager() {
        super(null);
    }
    
    
    public void newGame(Player player, String[] sicilyMaterials){
        game=new Game(player, sicilyMaterials);
        ageManager=new AgeManager(game);
        buildingManager=new BuildingManager(game);
        cityManager=new CityManager(game);
        foreignManager=new ForeignManager(game);
        materialAndHappinessManager=new MaterialAndHappinessManager(game);
        populationManager = new PopulationManager(game);
        recruitmentManager= new RecruitmentManager(game);
        terminationManager = new TerminationManager(game);
    }
    
    public boolean isBuildable(int id, int x, int y, boolean horizontal){
        if(id == 51)
            id=39;
        return buildingManager.isBuildable(game.getBuildings().getAllBuildings()[id], x, y, horizontal);
    }
    
    public boolean build(int id, int x, int y, boolean horizontal){
        if(id == 51)
            id=39;
        return buildingManager.build(game.getBuildings().getAllBuildings()[id], x, y, horizontal);
    }
    
    public void deleteBuilding(int x, int y){
        buildingManager.delete(x, y);
    }
    
    public void upgradeBuilding(int x, int y){
        buildingManager.updateBuilding(x, y);
    }
    
    public int getMoney(){
        return game.getMoney();
    }
    
    public int getProletariatPopulation(){
        return game.getPeople().getProletariat().getTotalPopulation();
    }
    
    public int getAristoiPopulation(){
        return game.getPeople().getAristoi().getTotalPopulation();
    }
    
    public int getProletariatHappiness(){
        return game.getPeople().getProletariat().getHappiness();
    }
    
    public int getUnemployedProletariat(){
        return game.getPeople().getProletariat().getUnemployed();
    }
    
    public int getUnemployedAristoi(){
        return game.getPeople().getAristoi().getUnemployed();
    }
    
    public int getAristoiHappiness(){
        return game.getPeople().getAristoi().getHappiness();
    }
}
