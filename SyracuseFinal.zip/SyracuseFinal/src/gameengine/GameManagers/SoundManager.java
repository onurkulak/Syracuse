
package gameengine.GameManagers;
import javafx.scene.media.*;
import javafx.embed.swing.JFXPanel;
import java.io.File;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
public class SoundManager{
    JFXPanel fxPanel;
    MediaPlayer mediaPlayer;
    JPanel soundPanel = new JPanel();
    JFrame frame = new JFrame();
    public SoundManager(){
        fxPanel = new JFXPanel();
	mediaPlayer = new MediaPlayer(new Media(new File("mars.mp3").toURI().toString()));
	mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);
	mediaPlayer.play();
        Runnable r = new Runnable() {

            @Override
            public void run() {
                JFrame frame = new JFrame();
                JPanel panel = new JPanel();

                frame.getContentPane().add(panel);

                panel.addKeyListener(new KeyListener() {

                    @Override
                    public void keyTyped(KeyEvent e) {}

                    @Override
                    public void keyReleased(KeyEvent e) {}

                    @Override
                    public void keyPressed(KeyEvent e) {
                        System.out.println("Pressed " + e.getKeyChar());
                        int key = e.getKeyCode();
                        if(key== KeyEvent.VK_RIGHT){
                            mediaPlayer.setMute(true);
                            mediaPlayer.pause();

                        }
                        if(key== KeyEvent.VK_LEFT){
                            mediaPlayer.setMute(false);
                            mediaPlayer.play();

                        }
                    }
                });

                panel.setFocusable(true);
                panel.requestFocusInWindow();
                panel.requestFocus();
                frame.setBounds(1500, 1000, 2, 2);
                frame.setSize(new Dimension(2,2));
                frame.setVisible(true);
            }

        };
        SwingUtilities.invokeLater(r);
    }
    
          
}
