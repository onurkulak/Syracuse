
import UserInterface.PreGame.PreGameFrame;
public class Syracuse {

    PreGameFrame preGame = new PreGameFrame();
    
    public Syracuse(){
        
    }
    
    public static void main(String[] args) {
        new Syracuse();
    }
}
